// Qtn 1
export const q1 = String.raw`
\begin{equation}
\text { If } \vec{a} \text { and } \vec{b} \text { are parallel vectors, then }[\vec{a}, \vec{c}, \vec{b}] \text { is equal to }
\end{equation}` ;

// opt A
export const optA1 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt B
export const optB1 = String.raw`
\begin{equation}
-1
\end{equation}` ;
// opt C
export const optC1 = String.raw`
\begin{equation}
1
\end{equation}` ;
// opt D
export const optD1 = String.raw`
\begin{equation}
0
\end{equation}` ;

// Qtn 2
export const q2 = String.raw`
\begin{equation}
\text { If a vector } \vec{\alpha} \text { lies in the plane of } \vec{\beta} \text { and } \vec{\gamma}, \text { then }
\end{equation}`;
// opt A
export const optA2 = String.raw`
\begin{equation}
[\vec{\alpha}, \vec{\beta}, \vec{\gamma}]=1
\end{equation}` ;
// opt B
export const optB2 = String.raw`
\begin{equation}
[\vec{\alpha}, \vec{\beta}, \vec{\gamma}]=-1
\end{equation}` ;
// opt C
export const optC2 = String.raw`
\begin{equation}
[\vec{\alpha}, \vec{\beta}, \vec{\gamma}]=0
\end{equation}` ;
// opt D
export const optD2 = String.raw`
\begin{equation}
[\vec{\alpha}, \vec{\beta}, \vec{\gamma}]=2
\end{equation}` ;

// Qtn 3
export const q3 = String.raw`
\begin{equation}
\text { If } \vec{a} \cdot \vec{b}=\vec{b} \cdot \vec{c}=\vec{c} \cdot \vec{a}=0, \text { then the value of }[\vec{a}, \vec{b}, \vec{c}] \text { is }
\end{equation}`;
// opt A
export const optA3 = String.raw`
\begin{equation}
|\vec{a}||\vec{b}||\vec{c}|
\end{equation}`;
// opt B
export const optB3 = String.raw`
\begin{equation}
\frac{1}{3}|\vec{a}||\vec{b}||\vec{c}|
\end{equation}` ;
// opt C
export const optC3 = String.raw`
\begin{equation}
1
\end{equation}` ;
// opt D
export const optD3 = String.raw`
\begin{equation}
-1
\end{equation}` ;

// Qtn 4
export const q4 = String.raw`
\begin{equation}
\text { If } \vec{a}, \vec{b}, \vec{c} \text { are three unit vectors such that } \vec{a} \text { is perpendicular to } \vec{b} \text { , and is parallel to } \vec{c} \text { then } \vec{a} \times(\vec{b} \times \vec{c}) \text { is equal to }
\end{equation}` ;

// opt A
export const optA4 = String.raw`
\begin{equation}
\vec{a}
\end{equation}`;
// opt B
export const optB4 = String.raw`
\begin{equation}
\vec{b}
\end{equation}` ;
// opt C
export const optC4 = String.raw`
\begin{equation}
\vec{c}
\end{equation}` ;
// opt D
export const optD4 = String.raw`
\begin{equation}
\vec{0}
\end{equation}` ;

// Qtn 5
export const q5 = String.raw`
\begin{equation}
\text { If }[\vec{a}, \vec{b}, \vec{c}]=1, \text { then the value of } \frac{\vec{a} \cdot(\vec{b} \times \vec{c})}{(\vec{c} \times \vec{a}) \cdot \vec{b}}+\frac{\vec{b} \cdot(\vec{c} \times \vec{a})}{(\vec{a} \times \vec{b}) \cdot \vec{c}}+\frac{\vec{c} \cdot(\vec{a} \times \vec{b})}{(\vec{c} \times \vec{b}) \cdot \vec{a}} \text { is }
\end{equation}` ;

// opt A
export const optA5 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt B
export const optB5 = String.raw`
\begin{equation}
-1
\end{equation}` ;
// opt C
export const optC5 = String.raw`
\begin{equation}
2
\end{equation}` ;
// opt D
export const optD5 = String.raw`
\begin{equation}
3
\end{equation}` ;

// Qtn 6
export const q6 = String.raw`
\begin{equation}
\text { The volume of the parallelepiped with its edges represented by the vectors } \hat{i}+\hat{j}, \hat{i}+2 \hat{j}, \hat{i}+\hat{j}+\pi \hat{k} \text { is }
\end{equation}` ;

// opt A
export const optA6 = String.raw`
\begin{equation}
\frac{\pi}{2}
\end{equation}`;
// opt B
export const optB6 = String.raw`
\begin{equation}
\frac{\pi}{3}
\end{equation}` ;
// opt C
export const optC6 = String.raw`
\begin{equation}
\pi
\end{equation}` ;
// opt D
export const optD6 = String.raw`
\begin{equation}
\frac{\pi}{4}
\end{equation}` ;

// Qtn 7
export const q7 = String.raw`
\begin{equation}
\text { If } \vec{a} \text { and } \vec{b} \text { are unit vectors such that }[\vec{a}, \vec{b}, \vec{a} \times \vec{b}]=\frac{1}{4}, \text { then the angle between } \vec{a} \text { and } \vec{b} \text { is }
\end{equation}`;

// opt A
export const optA7 = String.raw`
\begin{equation}
\frac{\pi}{6}
\end{equation}`;
// opt B
export const optB7 = String.raw`
\begin{equation}
\frac{\pi}{4}
\end{equation}`;
// opt C
export const optC7 = String.raw`
\begin{equation}
\frac{\pi}{3}
\end{equation}`;
// opt D
export const optD7 = String.raw`
\begin{equation}
\frac{\pi}{2}
\end{equation}`;

// Qtn 8
export const q8 = String.raw`
\begin{equation}
\text { If } \vec{a}=\hat{i}+\hat{j}+\hat{k}, \vec{b}=\hat{i}+\hat{j}, \vec{c}=\hat{i} \text { and }(\vec{a} \times \vec{b}) \times \vec{c}=\lambda \vec{a}+\mu \vec{b}, \text { then the value of } \lambda+\mu \text { is }
\end{equation}`;

// opt A
export const optA8 = String.raw`
\begin{equation}
0
\end{equation}`;
// opt B
export const optB8 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt C
export const optC8 = String.raw`
\begin{equation}
6
\end{equation}`;
// opt D
export const optD8 = String.raw`
\begin{equation}
3
\end{equation}`;

// Qtn 9
export const q9 = String.raw`
\begin{equation}
\text { If } \vec{a}, \vec{b}, \vec{c} \text { are non-coplanar, non-zero vectors such that } [\vec{a}, \vec{b}, \vec{c}]=3 \text { , then } \{[\vec{a} \times \vec{b}, \vec{b} \times \vec{c}, \vec{c} \times \vec{a}]\}^{2} \text { is equal to }
\end{equation}`;

// opt A
export const optA9 = String.raw`
\begin{equation}
81
\end{equation}`;
// opt B
export const optB9 = String.raw`
\begin{equation}
9
\end{equation}`;
// opt C
export const optC9 = String.raw`
\begin{equation}
27
\end{equation}`;
// opt D
export const optD9 = String.raw`
\begin{equation}
18
\end{equation}`;

// Qtn 10
export const q10 = String.raw`
\begin{equation}
\text { If } \vec{a}, \vec{b}, \vec{c} \text { are three non-coplanar unit vectors such that } \vec{a} \times(\vec{b} \times \vec{c})=\frac{\vec{b}+\vec{c}}{\sqrt{2}} \text { , then the angle between }\vec{a} \text { and } \vec{b} \text { is }
\end{equation}`;

// opt A
export const optA10 = String.raw`
\begin{equation}
\frac{\pi}{2}
\end{equation}`;
// opt B
export const optB10 = String.raw`
\begin{equation}
\frac{3 \pi}{4}
\end{equation}`;
// opt C
export const optC10 = String.raw`
\begin{equation}
\frac{\pi}{4}
\end{equation}`;
// opt D
export const optD10 = String.raw`
\begin{equation}
\pi
\end{equation}`;

// Qtn 11
export const q11 = String.raw`
\begin{equation}
\text { If the volume of the parallelepiped with } \vec{a} \times \vec{b}, \vec{b} \times \vec{c}, \vec{c} \times \vec{a} \text { as coterminous edges is 8 cubic units, then the volume of the parallelepiped with } (\vec{a} \times \vec{b}) \times(\vec{b} \times \vec{c}),(\vec{b} \times \vec{c}) \times(\vec{c} \times \vec{a}) \text { and } (\vec{c} \times \vec{a}) \times(\vec{a} \times \vec{b}) \text { as coterminous edges is, }
\end{equation}`;

// opt A
export const optA11 = String.raw`
\begin{equation}
8 \text { cubic units }
\end{equation}`;
// opt B
export const optB11 = String.raw`
\begin{equation}
512 \text { cubic units }
\end{equation}`;
// opt C
export const optC11 = String.raw`
\begin{equation}
64 \text { cubic units }
\end{equation}`;
// opt D
export const optD11 = String.raw`
\begin{equation}
24 \text { cubic units }
\end{equation}`;

// Qtn 12
export const q12 = String.raw`
\begin{equation}
\text { Consider the vectors } \vec{a}, \vec{b}, \vec{c}, \vec{d} \text { such that } (\vec{a} \times \vec{b}) \times(\vec{c} \times \vec{d})=\overrightarrow{0} \text { . Let } P_{1} \text { and } P_{2} \text { be the planes determined by the pairs of vectors } \vec{a}, \vec{b} \text { and } \vec{c}, \vec{d} \text { respectively. Then the angle between } P_{1} \text { and } P_{2} \text { is }
\end{equation}`;

// opt A
export const optA12 = String.raw`
\begin{equation}
0^{\circ}
\end{equation}`;
// opt B
export const optB12 = String.raw`
\begin{equation}
45^{\circ}
\end{equation}`;
// opt C
export const optC12 = String.raw`
\begin{equation}
60^{\circ}
\end{equation}`;
// opt D
export const optD12 = String.raw`
\begin{equation}
90^{\circ}
\end{equation}`;

// Qtn 13
export const q13 = String.raw`
\begin{equation}
\text { If } \vec{a} \times(\vec{b} \times \vec{c})=(\vec{a} \times \vec{b}) \times \vec{c} \text { , where } \vec{a}, \vec{b}, \vec{c} \text { are any three vectors such that } \vec{b} \cdot \vec{c} \neq 0 \text { and } \vec{a} \cdot \vec{b} \neq 0 \text { , then } \vec{a} \text { and } \vec{c} \text { are }
\end{equation}`;

// opt A
export const optA13 = String.raw`
\begin{equation}
\text { perpendicular } 
\end{equation}`;
// opt B
export const optB13 = String.raw`
\begin{equation}
\text { parallel } 
\end{equation}`;
// opt C
export const optC13 = String.raw`
\begin{equation}
\text { inclined at an angle } \frac{\pi}{3}
\end{equation}`;
// opt D
export const optD13 = String.raw`
\begin{equation}
\text { inclined at an angle } \frac{\pi}{6}
\end{equation}`;

// Qtn 14
export const q14 = String.raw`
\begin{equation}
\text { If } \vec{a}=2 \hat{i}+3 \hat{j}-\hat{k}, \vec{b}=\hat{i}+2 \hat{j}-5 \hat{k}, \vec{c}=3 \hat{i}+5 \hat{j}-\hat{k} \text { , then a vector perpendicular to } \vec{a} \text { and lies in the plane containing } \vec{b} \text { and } \vec{c} \text { is }
\end{equation}`;

// opt A
export const optA14 = String.raw`
\begin{equation}
-17 \hat{i}+21 \hat{j}-97 \hat{k}
\end{equation}`;
// opt B
export const optB14 = String.raw`
\begin{equation}
17 \hat{i}+21 \hat{j}-123 \hat{k}
\end{equation}`;
// opt C
export const optC14 = String.raw`
\begin{equation}
-17 \hat{i}-21 \hat{j}+97 \hat{k}
\end{equation}`;
// opt D
export const optD14 = String.raw`
\begin{equation}
-17 \hat{i}-21 \hat{j}-97 \hat{k}
\end{equation}`;

// Qtn 15
export const q15 = String.raw`
\begin{equation}
\text { The angle between the lines } \frac{x-2}{3}=\frac{y+1}{-2}, z=2 \text { and } \frac{x-1}{1}=\frac{2 y+3}{3}=\frac{z+5}{2} \text { is }
\end{equation}`;

// opt A
export const optA15 = String.raw`
\begin{equation}
\frac{\pi}{6}
\end{equation}`;
// opt B
export const optB15 = String.raw`
\begin{equation}
\frac{\pi}{4}
\end{equation}`;
// opt C
export const optC15 = String.raw`
\begin{equation}
\frac{\pi}{3}
\end{equation}`;	
// opt D
export const optD15 = String.raw`
\begin{equation}
\frac{\pi}{2}
\end{equation}`;

// Qtn 16
export const q16 = String.raw`
\begin{equation}
\text { The angle between the line } \vec{r}=(\hat{i}+2 \hat{j}-3 \hat{k})+t(2 \hat{i}+\hat{j}-2 \hat{k}) \text { and the plane } \vec{r} \cdot(\hat{i}+\hat{j})+4=0 \text { is }
\end{equation}`;

// opt A
export const optA16 = String.raw`
\begin{equation}
0^{\circ}
\end{equation}`;
// opt B
export const optB16 = String.raw`
\begin{equation}
30^{\circ}
\end{equation}`;	
// opt C
export const optC16 = String.raw`
\begin{equation}
45^{\circ}
\end{equation}`;	
// opt D
export const optD16 = String.raw`
\begin{equation}
90^{\circ}
\end{equation}`;

// Qtn 17
export const q17 = String.raw`
\begin{equation}
\text { Distance from the origin to the plane } 3 x-6 y+2 z+7=0 \text { is }
\end{equation}`;

// opt A
export const optA17 = String.raw`
\begin{equation}
0
\end{equation}`;
// opt B
export const optB17 = String.raw`
\begin{equation}
1
\end{equation}`;	
// opt C
export const optC17 = String.raw`
\begin{equation}
2
\end{equation}`;	
// opt D
export const optD17 = String.raw`
\begin{equation}
3
\end{equation}`;

// Qtn 18
export const q18 = String.raw`
\begin{equation}
\text { The distance between the planes } x+2 y+3 z+7=0 \text { and } 2 x+4 y+6 z+7=0 \text { is }
\end{equation}`;

// opt A
export const optA18 = String.raw`
\begin{equation}
\frac{\sqrt{7}}{2 \sqrt{2}}
\end{equation}`;
// opt B
export const optB18 = String.raw`
\begin{equation}
\frac{7}{2}
\end{equation}`;	
// opt C
export const optC18 = String.raw`
\begin{equation}
\frac{\sqrt{7}}{2}
\end{equation}`;	
// opt D
export const optD18 = String.raw`
\begin{equation}
\frac{7}{2 \sqrt{2}}
\end{equation}`;

// Qtn 19
export const q19 = String.raw`
\begin{equation}
\text { If the direction cosines of a line are } \frac{1}{c}, \frac{1}{c}, \frac{1}{c}, \text { then }
\end{equation}`;

// opt A
export const optA19 = String.raw`
\begin{equation}
c=\pm 3
\end{equation}`;
// opt B
export const optB19 = String.raw`
\begin{equation}
c=\pm \sqrt{3}
\end{equation}`;	
// opt C
export const optC19 = String.raw`
\begin{equation}
c>0
\end{equation}`;	
// opt D
export const optD19 = String.raw`
\begin{equation}
0 < c < 1
\end{equation}`;

// Qtn 20
export const q20 = String.raw`
\begin{equation}
\text { The vector equation } \vec{r}=(\hat{i}-2 \hat{j}-\hat{k})+t(6 \hat{j}-\hat{k}) \text { represents a straight line passing through the points }
\end{equation}`;

// opt A
export const optA20 = String.raw`
\begin{equation}
(0,6,-1) \text { and }(1,-2,-1)
\end{equation}`;
// opt B
export const optB20 = String.raw`
\begin{equation}
(0,6,-1) \text { and }(-1,-4,-2)
\end{equation}`;	
// opt C
export const optC20 = String.raw`
\begin{equation}
(1,-2,-1) \text { and }(1,4,-2)
\end{equation}`;	
// opt D
export const optD20 = String.raw`
\begin{equation}
(1,-2,-1) \text { and }(0,-6,1)
\end{equation}`;

// Qtn 21
export const q21 = String.raw`
\begin{equation}
\text { If the distance of the point } (1,1,1) \text { from the origin is half of its distance from the plane } x+y+z+k=0 \text {, then the values of } k \text { are }
\end{equation}`;

// opt A
export const optA21 = String.raw`
\begin{equation}
\pm 3
\end{equation}`;
// opt B
export const optB21 = String.raw`
\begin{equation}
\pm 6
\end{equation}`;	
// opt C
export const optC21 = String.raw`
\begin{equation}
-3,9
\end{equation}`;	
// opt D
export const optD21 = String.raw`
\begin{equation}
3,-9
\end{equation}`;

// Qtn 22
export const q22 = String.raw`
\begin{equation}
\text { If the planes } \vec{r} \cdot(2 \hat{i}-\lambda \hat{j}+\hat{k})=3 \text { and } \vec{r} \cdot(4 \hat{i}+\hat{j}-\mu \hat{k})=5 \text { are parallel, then the value of } \lambda \text { and } \mu \text { are }
\end{equation}`;

// opt A
export const optA22 = String.raw`
\begin{equation}
\frac{1}{2},-2
\end{equation}`;
// opt B
export const optB22 = String.raw`
\begin{equation}
-\frac{1}{2},2
\end{equation}`;	
// opt C
export const optC22 = String.raw`
\begin{equation}
-\frac{1}{2},-2
\end{equation}`;	
// opt D
export const optD22 = String.raw`
\begin{equation}
\frac{1}{2},2
\end{equation}`;

// Qtn 23
export const q23 = String.raw`
\begin{equation}
\text { If the length of the perpendicular from the origin to the plane } 2 x+3 y+\lambda z=1, \lambda>0 \text { is } \frac{1}{5} \text { , then the value of } \lambda \text { is }
\end{equation}`;

// opt A
export const optA23 = String.raw`
\begin{equation}
2 \sqrt{3}
\end{equation}`;
// opt B
export const optB23 = String.raw`
\begin{equation}
3 \sqrt{2}
\end{equation}`;	
// opt C
export const optC23 = String.raw`
\begin{equation}
0
\end{equation}`;	
// opt D
export const optD23 = String.raw`
\begin{equation}
1
\end{equation}`;

// // Qtn 24
// export const q24 = String.raw`
// `;

// // opt A
// export const optA24 = String.raw`
// `;
// // opt B
// export const optB24 = String.raw`
// `;	
// // opt C
// export const optC24 = String.raw`
// `;	
// // opt D
// export const optD24 = String.raw`
// `;

// // Qtn 25
// export const q25 = String.raw`
// `;

// // opt A
// export const optA25 = String.raw`
// `;
// // opt B
// export const optB25 = String.raw`
// `;	
// // opt C
// export const optC25 = String.raw`
// `;	
// // opt D
// export const optD25 = String.raw`
// `;





