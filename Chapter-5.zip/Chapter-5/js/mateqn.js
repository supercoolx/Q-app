// Qtn 1
export const q1 = String.raw`
\begin{equation}
\text { The equation of the circle passing through } (1,5) \text { and } (4,1) \text { and touching } y \text { -axis is } x^{2}+y^{2}-5 x-6 y+9+\lambda(4 x+3 y-19)=0 \text { where } \lambda \text { is equal to }
\end{equation}` ;

// opt A
export const optA1 = String.raw`
\begin{equation}
0,-\frac{40}{9}
\end{equation}`;
// opt B
export const optB1 = String.raw`
\begin{equation}
0
\end{equation}` ;
// opt C
export const optC1 = String.raw`
\begin{equation}
\frac{40}{9}
\end{equation}` ;
// opt D
export const optD1 = String.raw`
\begin{equation}
-\frac{40}{9}
\end{equation}` ;

// Qtn 2
export const q2 = String.raw`
\begin{equation}
\text { The eccentricity of the hyperbola whose latus rectum is 8 and conjugate axis is equal to half the distance between the foci is }
\end{equation}`;
// opt A
export const optA2 = String.raw`
\begin{equation}
\frac{4}{3}
\end{equation}` ;
// opt B
export const optB2 = String.raw`
\begin{equation}
\frac{4}{\sqrt{3}}
\end{equation}` ;
// opt C
export const optC2 = String.raw`
\begin{equation}
\frac{2}{\sqrt{3}}
\end{equation}` ;
// opt D
export const optD2 = String.raw`
\begin{equation}
\frac{3}{2}
\end{equation}` ;

// Qtn 3
export const q3 = String.raw`
\begin{equation}
\text { The circle } x^{2}+y^{2}=4 x+8 y+5 \text { intersects the line } 3 x-4 y=m \text { at two distinct points if }
\end{equation}`;
// opt A
export const optA3 = String.raw`
\begin{equation}
\text { 15 < m < 65 }
\end{equation}`;
// opt B
export const optB3 = String.raw`
\begin{equation}
\text { 35 < m < 85 }
\end{equation}` ;
// opt C
export const optC3 = String.raw`
\begin{equation}
\text { -85 < m < -35 }
\end{equation}` ;
// opt D
export const optD3 = String.raw`
\begin{equation}
\text { -35 < m < 15 }
\end{equation}` ;

// Qtn 4
export const q4 = String.raw`
\begin{equation}
\text { The length of the diameter of the circle which touches the } x \text {-axis at the point } (1,0) \text { and passes through the point }(2,3).
\end{equation}` ;

// opt A
export const optA4 = String.raw`
\begin{equation}
\frac{6}{5}
\end{equation}`;
// opt B
export const optB4 = String.raw`
\begin{equation}
\frac{5}{3}
\end{equation}` ;
// opt C
export const optC4 = String.raw`
\begin{equation}
\frac{10}{3}
\end{equation}` ;
// opt D
export const optD4 = String.raw`
\begin{equation}
\frac{3}{5}
\end{equation}` ;

// Qtn 5
export const q5 = String.raw`
\begin{equation}
\text { The radius of the circle } 3 x^{2}+b y^{2}+4 b x-6 b y+b^{2}=0 \text { is }
\end{equation}` ;

// opt A
export const optA5 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt B
export const optB5 = String.raw`
\begin{equation}
3
\end{equation}` ;
// opt C
export const optC5 = String.raw`
\begin{equation}
\sqrt{10}
\end{equation}` ;
// opt D
export const optD5 = String.raw`
\begin{equation}
\sqrt{11}
\end{equation}` ;

// Qtn 6
export const q6 = String.raw`
\begin{equation}
\text { The centre of the circle inscribed in a square formed by the lines } x^{2}-8 x-12=0 \text { and } y^{2}-14 y+45=0 \text { is }
\end{equation}` ;

// opt A
export const optA6 = String.raw`
\begin{equation}
(4,7)
\end{equation}`;
// opt B
export const optB6 = String.raw`
\begin{equation}
(7,4)
\end{equation}` ;
// opt C
export const optC6 = String.raw`
\begin{equation}
(9,4)
\end{equation}` ;
// opt D
export const optD6 = String.raw`
\begin{equation}
(4,9)
\end{equation}` ;

// Qtn 7
export const q7 = String.raw`
\begin{equation}
\text { The equation of the normal to the circle } x^{2}+y^{2}-2 x-2 y+1=0 \text { which is parallel to the line } 2 x+4 y=3 \text { is }
\end{equation}`;

// opt A
export const optA7 = String.raw`
\begin{equation}
x+2 y=3
\end{equation}`;
// opt B
export const optB7 = String.raw`
\begin{equation}
x+2 y+3=0
\end{equation}`;
// opt C
export const optC7 = String.raw`
\begin{equation}
2 x+4 y+3=0
\end{equation}`;
// opt D
export const optD7 = String.raw`
\begin{equation}
x-2 y+3=0
\end{equation}`;

// Qtn 8
export const q8 = String.raw`
\begin{equation}
\text { If } P(x, y) \text { be any point on } 16 x^{2}+25 y^{2}=400 \text { with foci } F_{1}(3,0) \text { and } F_{2}(-3,0) \text { then } P F_{1}+P F_{2} \text { is }
\end{equation}`;

// opt A
export const optA8 = String.raw`
\begin{equation}
8
\end{equation}`;
// opt B
export const optB8 = String.raw`
\begin{equation}
6
\end{equation}`;
// opt C
export const optC8 = String.raw`
\begin{equation}
10
\end{equation}`;
// opt D
export const optD8 = String.raw`
\begin{equation}
12
\end{equation}`;

// Qtn 9
export const q9 = String.raw`
\begin{equation}
\text { The radius of the circle passing through the point } (6,2) \text { two of whose diameter are } x+y=6 \text { and } x+2 y=4 \text { is }
\end{equation}`;

// opt A
export const optA9 = String.raw`
\begin{equation}
10
\end{equation}`;
// opt B
export const optB9 = String.raw`
\begin{equation}
2 \sqrt{5}
\end{equation}`;
// opt C
export const optC9 = String.raw`
\begin{equation}
6
\end{equation}`;
// opt D
export const optD9 = String.raw`
\begin{equation}
4
\end{equation}`;

// Qtn 10
export const q10 = String.raw`
\begin{equation}
\text { The area of quadrilateral formed with foci of the hyperbolas } \frac{x^{2}}{a^{2}}-\frac{y^{2}}{b^{2}}=1 \text { and } \frac{x^{2}}{a^{2}}-\frac{y^{2}}{b^{2}}=-1 \text { is }
\end{equation}`;

// opt A
export const optA10 = String.raw`
\begin{equation}
4\left(a^{2}+b^{2}\right)
\end{equation}`;
// opt B
export const optB10 = String.raw`
\begin{equation}
2\left(a^{2}+b^{2}\right)
\end{equation}`;
// opt C
export const optC10 = String.raw`
\begin{equation}
a^{2}+b^{2}
\end{equation}`;
// opt D
export const optD10 = String.raw`
\begin{equation}
\frac{1}{2}\left(a^{2}+b^{2}\right)
\end{equation}`;

// Qtn 11
export const q11 = String.raw`
\begin{equation}
\text { If the normals of the parabola } y^{2}=4 x \text { drawn at the end points of its latus rectum are tangents to the circle } (x-3)^{2}+(y+2)^{2}=r^{2} \text { , then the value of } r^{2} \text { is }
\end{equation}`;

// opt A
export const optA11 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt B
export const optB11 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt C
export const optC11 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt D
export const optD11 = String.raw`
\begin{equation}
4
\end{equation}`;

// Qtn 12
export const q12 = String.raw`
\begin{equation}
\text { If } x+y=k \text { is a normal to the parabola } y^{2}=12 x, \text { then the value of } k \text { is }
\end{equation}`;

// opt A
export const optA12 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt B
export const optB12 = String.raw`
\begin{equation}
-1
\end{equation}`;
// opt C
export const optC12 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt D
export const optD12 = String.raw`
\begin{equation}
9
\end{equation}`;

// Qtn 13
export const q13 = String.raw`
\begin{equation}
\text { The ellipse } E_{1}: \frac{x^{2}}{9}+\frac{y^{2}}{4}=1 \text { is inscribed in a rectangle } R \text { whose sides are parallel to the coordinate axes. Another ellipse } E_{2} \text { passing through the point } (0,4) \text { circumscribes the rectangle } R \text { . The eccentricity of the ellipse is }
\end{equation}`;

// opt A
export const optA13 = String.raw`
\begin{equation}
\frac{\sqrt{2}}{2}
\end{equation}`;
// opt B
export const optB13 = String.raw`
\begin{equation}
\frac{\sqrt{3}}{2}
\end{equation}`;
// opt C
export const optC13 = String.raw`
\begin{equation}
\frac{1}{2}
\end{equation}`;
// opt D
export const optD13 = String.raw`
\begin{equation}
\frac{3}{4}
\end{equation}`;

// Qtn 14
export const q14 = String.raw`
\begin{equation}
\text { Tangents are drawn to the hyperbola } \frac{x^{2}}{9}-\frac{y^{2}}{4}=1 \text { parallel to the straight line } 2 x-y=1 .\text { One of the points of contact of tangents on the hyperbola is }
\end{equation}`;

// opt A
export const optA14 = String.raw`
\begin{equation}
\left(\frac{9}{2 \sqrt{2}}, \frac{-1}{\sqrt{2}}\right)
\end{equation}`;
// opt B
export const optB14 = String.raw`
\begin{equation}
\left(\frac{-9}{2 \sqrt{2}}, \frac{1}{\sqrt{2}}\right)
\end{equation}`;
// opt C
export const optC14 = String.raw`
\begin{equation}
\left(\frac{9}{2 \sqrt{2}}, \frac{1}{\sqrt{2}}\right)
\end{equation}`;
// opt D
export const optD14 = String.raw`
\begin{equation}
(3 \sqrt{3},-2 \sqrt{2})
\end{equation}`;

// Qtn 15
export const q15 = String.raw`
\begin{equation}
\text { The equation of the circle passing through the foci of the ellipse } \frac{x^{2}}{16}+\frac{y^{2}}{9}=1 \text { having centre at } (0,3) \text { is }
\end{equation}`;

// opt A
export const optA15 = String.raw`
\begin{equation}
x^{2}+y^{2}-6 y-7=0
\end{equation}`;
// opt B
export const optB15 = String.raw`
\begin{equation}
x^{2}+y^{2}-6 y+7=0
\end{equation}`;
// opt C
export const optC15 = String.raw`
\begin{equation}
x^{2}+y^{2}-6 y-5=0
\end{equation}`;	
// opt D
export const optD15 = String.raw`
\begin{equation}
x^{2}+y^{2}-6 y+5=0
\end{equation}`;

// Qtn 16
export const q16 = String.raw`
\begin{equation}
\text { Let } C \text { be the circle with centre at } (1,1) \text { and radius } =1 . \text { If } T \text { is the circle centered at } (0, y) \text { passing through the origin and touching the circle } C \text { externally, then the radius of } T \text { is equal to }
\end{equation}`;

// opt A
export const optA16 = String.raw`
\begin{equation}
\frac{\sqrt{3}}{\sqrt{2}}
\end{equation}`;
// opt B
export const optB16 = String.raw`
\begin{equation}
\frac{\sqrt{3}}{2}
\end{equation}`;	
// opt C
export const optC16 = String.raw`
\begin{equation}
\frac{1}{2}
\end{equation}`;	
// opt D
export const optD16 = String.raw`
\begin{equation}
\frac{1}{4}
\end{equation}`;

// Qtn 17
export const q17 = String.raw`
\begin{equation}
\text { Consider an ellipse whose centre is of the origin and its major axis is along } x \text { -axis. If its eccentrcity is } \frac{3}{5} \text { and the distance between its foci is 6, then the area of the quadrilateral inscribed in the ellipse with diagonals as major and minor axis of the ellipse is }
\end{equation}`;

// opt A
export const optA17 = String.raw`
\begin{equation}
8
\end{equation}`;
// opt B
export const optB17 = String.raw`
\begin{equation}
32
\end{equation}`;	
// opt C
export const optC17 = String.raw`
\begin{equation}
80
\end{equation}`;	
// opt D
export const optD17 = String.raw`
\begin{equation}
40
\end{equation}`;

// Qtn 18
export const q18 = String.raw`
\begin{equation}
\text { Area of the greatest rectangle inscribed in the ellipse } \frac{x^{2}}{a^{2}}+\frac{y^{2}}{b^{2}}=1 \text { is }
\end{equation}`;

// opt A
export const optA18 = String.raw`
\begin{equation}
2 a b
\end{equation}`;
// opt B
export const optB18 = String.raw`
\begin{equation}
a b
\end{equation}`;	
// opt C
export const optC18 = String.raw`
\begin{equation}
\sqrt{a b}
\end{equation}`;	
// opt D
export const optD18 = String.raw`
\begin{equation}
\frac{a}{b}
\end{equation}`;

// Qtn 19
export const q19 = String.raw`
\begin{equation}
\text { An ellipse has } O B \text { as semi minor axes, } F \text { and } F^{\prime} \text { its foci and the angle } F B F^{\prime} \text { is a right angle. Then the eccentricity of the ellipse is }
\end{equation}`;

// opt A
export const optA19 = String.raw`
\begin{equation}
\frac{1}{\sqrt{2}}
\end{equation}`;
// opt B
export const optB19 = String.raw`
\begin{equation}
\frac{1}{2}
\end{equation}`;	
// opt C
export const optC19 = String.raw`
\begin{equation}
\frac{1}{4}
\end{equation}`;	
// opt D
export const optD19 = String.raw`
\begin{equation}
\frac{1}{\sqrt{3}}
\end{equation}`;

// Qtn 20
export const q20 = String.raw`
\begin{equation}
\text { The eccentricity of the ellipse }(x-3)^{2}+(y-4)^{2}=\frac{y^{2}}{9} \text { is }
\end{equation}`;

// opt A
export const optA20 = String.raw`
\begin{equation}
\frac{\sqrt{3}}{2}
\end{equation}`;
// opt B
export const optB20 = String.raw`
\begin{equation}
\frac{1}{3}
\end{equation}`;	
// opt C
export const optC20 = String.raw`
\begin{equation}
\frac{1}{3 \sqrt{2}}
\end{equation}`;	
// opt D
export const optD20 = String.raw`
\begin{equation}
\frac{1}{\sqrt{3}}
\end{equation}`;

// Qtn 21
export const q21 = String.raw`
\begin{equation}
\text { If the two tangents drawn from a point } P \text { to the parabola } y^{2}=4 x \text { are at right angles then the locus of } P \text { is }
\end{equation}`;

// opt A
export const optA21 = String.raw`
\begin{equation}
2 x+1=0
\end{equation}`;
// opt B
export const optB21 = String.raw`
\begin{equation}
x=-1
\end{equation}`;	
// opt C
export const optC21 = String.raw`
\begin{equation}
2 x-1=0
\end{equation}`;	
// opt D
export const optD21 = String.raw`
\begin{equation}
x=1
\end{equation}`;

// Qtn 22
export const q22 = String.raw`
\begin{equation}
\text { The circle passing through }(1,-2) \text { and touching the axis of } x \text { at }(3,0) \text { passing through the point }
\end{equation}`;

// opt A
export const optA22 = String.raw`
\begin{equation}
(-5,2)
\end{equation}`;
// opt B
export const optB22 = String.raw`
\begin{equation}
(2,-5)
\end{equation}`;	
// opt C
export const optC22 = String.raw`
\begin{equation}
(5,-2)
\end{equation}`;	
// opt D
export const optD22 = String.raw`
\begin{equation}
(-2,5)
\end{equation}`;

// Qtn 23
export const q23 = String.raw`
\begin{equation}
\text { The locus of a point whose distance from } (-2,0) \text { is } \frac{2}{3} \text { times its distance from the line } x=\frac{-9}{2} \text { is }
\end{equation}`;

// opt A
export const optA23 = String.raw`
\begin{equation}
\text { a parabola }
\end{equation}`;
// opt B
export const optB23 = String.raw`
\begin{equation}
\text { a hyperbola }
\end{equation}`;	
// opt C
export const optC23 = String.raw`
\begin{equation}
\text { an ellipse }
\end{equation}`;	
// opt D
export const optD23 = String.raw`
\begin{equation}
\text { a circle }
\end{equation}`;

// Qtn 24
export const q24 = String.raw`
\begin{equation}
\text { The values of $m$ for which the line } y=m x+2 \sqrt{5} \text { touches the hyperbola } 16 x^{2}-9 y^{2}=144 \text { are the roots of } x^{2}-(a+b) x-4=0 \text {, then the value of } (a+b) \text { is }
\end{equation}`;

// opt A
export const optA24 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt B
export const optB24 = String.raw`
\begin{equation}
4
\end{equation}`;	
// opt C
export const optC24 = String.raw`
\begin{equation}
0
\end{equation}`;	
// opt D
export const optD24 = String.raw`
\begin{equation}
-2
\end{equation}`;

// Qtn 25
export const q25 = String.raw`
\begin{equation}
\text { If the coordinates at one end of a diameter of the circle } x^{2}+y^{2}-8 x-4 y+c=0 \text { are } (11,2) \text { , the coordinates of the other end are }
\end{equation}`;

// opt A
export const optA25 = String.raw`
\begin{equation}
(-5,2)
\end{equation}`;
// opt B
export const optB25 = String.raw`
\begin{equation}
(-3,2)
\end{equation}`;	
// opt C
export const optC25 = String.raw`
\begin{equation}
(5,-2)
\end{equation}`;	
// opt D
export const optD25 = String.raw`
\begin{equation}
(-2,5)
\end{equation}`;





