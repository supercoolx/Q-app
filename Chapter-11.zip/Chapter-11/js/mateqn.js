// Qtn 1
export const q1 = String.raw`
\begin{equation}
\text { Let } X \text { be random variable with probability density function } f(x)= \begin{cases}\frac{2}{x^{3}} & x \geq 1 \\ 0 & x<1\end{cases} \text { Which of the following statement is correct? }
\end{equation}` ;

// opt A
export const optA1 = String.raw`
\begin{equation}
\text { both mean and variance exist }
\end{equation}`;
// opt B
export const optB1 = String.raw`
\begin{equation}
\text { mean exists but variance does not exist }
\end{equation}` ;
// opt C
export const optC1 = String.raw`
\begin{equation}
\text { both mean and variance do not exist }
\end{equation}` ;
// opt D
export const optD1 = String.raw`
\begin{equation}
\text { variance exists but Mean does not exist }
\end{equation}` ;

// Qtn 2
export const q2 = String.raw`
\begin{equation}
\text { A rod of length } 2 l \text { is broken into two pieces at random. The probability density function of the shorter of the two pieces is } f(x)= \begin{cases}\frac{1}{l} & 0 < x < l \\ 0 & l \leq x < 2 l\end{cases} \text { The mean and variance of the shorter of the two pieces are respectively }
\end{equation}`;
// opt A
export const optA2 = String.raw`
\begin{equation}
\frac{l}{2}, \frac{l^{2}}{3}
\end{equation}` ;
// opt B
export const optB2 = String.raw`
\begin{equation}
\frac{l}{2}, \frac{l^{2}}{6}
\end{equation}` ;
// opt C
export const optC2 = String.raw`
\begin{equation}
l, \frac{l^{2}}{12}
\end{equation}` ;
// opt D
export const optD2 = String.raw`
\begin{equation}
\frac{l}{2}, \frac{l^{2}}{12}
\end{equation}` ;

// Qtn 3
export const q3 = String.raw`
\begin{equation}
\text { Consider a game where the player tosses a six-sided fair die. If the face that comes up is 6 , the player wins ₹ 36 , otherwise he loses ₹ } k^{2} \text { , where } k \text { is the face that comes up } k=\{1,2,3,4,5\} \text { . The expected amount to win at this game in } ₹ \text { is }
\end{equation}`;
// opt A
export const optA3 = String.raw`
\begin{equation}
\frac{19}{6}
\end{equation}`;
// opt B
export const optB3 = String.raw`
\begin{equation}
-\frac{19}{6}
\end{equation}` ;
// opt C
export const optC3 = String.raw`
\begin{equation}
\frac{3}{2}
\end{equation}` ;
// opt D
export const optD3 = String.raw`
\begin{equation}
-\frac{3}{2}
\end{equation}` ;

// Qtn 4
export const q4 = String.raw`
\begin{equation}
\text { A pair of dice numbered } 1,2,3,4,5,6 \text { of a six-sided die and } 1,2,3,4 \text { of a four-sided die is rolled and the sum is determined. Let the random variable } X \text { denote this sum. Then the number of elements in the inverse image of 7 is }
\end{equation}` ;

// opt A
export const optA4 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt B
export const optB4 = String.raw`
\begin{equation}
2
\end{equation}` ;
// opt C
export const optC4 = String.raw`
\begin{equation}
3
\end{equation}` ;
// opt D
export const optD4 = String.raw`
\begin{equation}
4
\end{equation}` ;

// Qtn 5
export const q5 = String.raw`
\begin{equation}
\text { A random variable } X \text { has binomial distribution with } n=25 \text { and } p=0.8 \text { then standard deviation of } X \text { is }
\end{equation}` ;

// opt A
export const optA5 = String.raw`
\begin{equation}
6
\end{equation}`;
// opt B
export const optB5 = String.raw`
\begin{equation}
4
\end{equation}` ;
// opt C
export const optC5 = String.raw`
\begin{equation}
3
\end{equation}` ;
// opt D
export const optD5 = String.raw`
\begin{equation}
2
\end{equation}` ;

// Qtn 6
export const q6 = String.raw`
\begin{equation}
\text { Let } X \text { represent the difference between the number of heads and the number of tails obtained when a coin is tossed } n \text { times. Then the possible values of } X \text { are }
\end{equation}` ;

// opt A
export const optA6 = String.raw`
\begin{equation}
i+2 n, i=0,1,2 \ldots n
\end{equation}`;
// opt B
export const optB6 = String.raw`
\begin{equation}
2 i-n, i=0,1,2 \ldots n
\end{equation}` ;
// opt C
export const optC6 = String.raw`
\begin{equation}
n-i, i=0,1,2 \ldots n
\end{equation}` ;
// opt D
export const optD6 = String.raw`
\begin{equation}
2 i+2 n, i=0,1,2 \ldots n
\end{equation}` ;

// Qtn 7
export const q7 = String.raw`
\begin{equation}
\text { If the function } f(x)=\frac{1}{12} \text { for } a < x < b \text { , represents a probability density function of a continuous random variable } X \text {, then which of the following cannot be the value of } a \text { and } b \text { ? }
\end{equation}`;

// opt A
export const optA7 = String.raw`
\begin{equation}
0 \text { and } 12
\end{equation}`;
// opt B
export const optB7 = String.raw`
\begin{equation}
5 \text { and } 17
\end{equation}`;
// opt C
export const optC7 = String.raw`
\begin{equation}
7 \text { and } 19
\end{equation}`;
// opt D
export const optD7 = String.raw`
\begin{equation}
16 \text { and } 24
\end{equation}`;

// Qtn 8
export const q8 = String.raw`
\begin{equation}
\text { Four buses carrying 160 students from the same school arrive at a football stadium. The buses carry, respectively, } 42,36,34 \text { , and 48 students. One of the students is randomly selected. Let } X \text { denote the number of students that were on the bus carrying the randomly selected student. One of the 4 bus drivers is also randomly selected. Let } Y \text { denote the number of students on that bus. Then } E(X) \text { and } E(Y) \text { respectively are }
\end{equation}`;

// opt A
export const optA8 = String.raw`
\begin{equation}
50,40
\end{equation}`;
// opt B
export const optB8 = String.raw`
\begin{equation}
40,50
\end{equation}`;
// opt C
export const optC8 = String.raw`
\begin{equation}
40.75,40
\end{equation}`;
// opt D
export const optD8 = String.raw`
\begin{equation}
41,41
\end{equation}`;

// Qtn 9
export const q9 = String.raw`
\begin{equation}
\text { Two coins are to be flipped. The first coin will land on heads with probability } 0.6 \text {, the second with Probability } 0.5 \text {. Assume that the results of the flips are independent, and let } X \text { equal the total number of heads that result. The value of } E(X) \text { is }
\end{equation}`;

// opt A
export const optA9 = String.raw`
\begin{equation}
0.11
\end{equation}`;
// opt B
export const optB9 = String.raw`
\begin{equation}
1.1
\end{equation}`;
// opt C
export const optC9 = String.raw`
\begin{equation}
11
\end{equation}`;
// opt D
export const optD9 = String.raw`
\begin{equation}
1
\end{equation}`;

// Qtn 10
export const q10 = String.raw`
\begin{equation}
\text { On a multiple-choice exam with 3 possible destructives for each of the 5 questions, the probability that a student will get 4 or more correct answers just by guessing is }
\end{equation}`;

// opt A
export const optA10 = String.raw`
\begin{equation}
\frac{11}{243}
\end{equation}`;
// opt B
export const optB10 = String.raw`
\begin{equation}
\frac{3}{8}
\end{equation}`;
// opt C
export const optC10 = String.raw`
\begin{equation}
\frac{1}{243}
\end{equation}`;
// opt D
export const optD10 = String.raw`
\begin{equation}
\frac{5}{243}
\end{equation}`;

// Qtn 11
export const q11 = String.raw`
\begin{equation}
\text { If } P(X=0)=1-P(X=1) \text {. If } E(X)=3 \operatorname{Var}(X) \text {, then } P(X=0) \text { is }
\end{equation}`;

// opt A
export const optA11 = String.raw`
\begin{equation}
\frac{2}{3}
\end{equation}`;
// opt B
export const optB11 = String.raw`
\begin{equation}
\frac{2}{5}
\end{equation}`;
// opt C
export const optC11 = String.raw`
\begin{equation}
\frac{1}{5}
\end{equation}`;
// opt D
export const optD11 = String.raw`
\begin{equation}
\frac{1}{3}
\end{equation}`;

// Qtn 12
export const q12 = String.raw`
\begin{equation}
\text { If } X \text { is a binomial random variable with expected value 6 and variance } 2.4 \text {, then } P(X=5) \text { is }
\end{equation}`;

// opt A
export const optA12 = String.raw`
\begin{equation}
\left(\begin{array}{c}
10 \\
5
\end{array}\right)\left(\frac{3}{5}\right)^{6}\left(\frac{2}{5}\right)^{4}
\end{equation}`;
// opt B
export const optB12 = String.raw`
\begin{equation}
\left(\begin{array}{c}
10 \\
5
\end{array}\right)\left(\frac{3}{5}\right)^{10}
\end{equation}`;
// opt C
export const optC12 = String.raw`
\begin{equation}
\left(\begin{array}{c}
10 \\
5
\end{array}\right)\left(\frac{3}{5}\right)^{4}\left(\frac{2}{5}\right)^{6}
\end{equation}`;
// opt D
export const optD12 = String.raw`
\begin{equation}
\left(\begin{array}{c}
10 \\
5
\end{array}\right)\left(\frac{3}{5}\right)^{5}\left(\frac{2}{5}\right)^{5}
\end{equation}`;

// Qtn 13
export const q13 = String.raw`
\begin{equation}
\text { The random variable } \mathrm{X} \text { has the probability density function }
\end{equation}
\begin{equation}
f(x)=\left\{\begin{array}{l}
a x+b & 0 < x < 1 \\
0 & otherwise 
\end{array}\right.
\end{equation}
\begin{equation}
\text { otherwise and } E(X)=\frac{7}{12} \text {, then } a \text { and } b \text { are respectively }
\end{equation}`;

// opt A
export const optA13 = String.raw`
\begin{equation}
1 \text { and } \frac{1}{2}
\end{equation}`;
// opt B
export const optB13 = String.raw`
\begin{equation}
\frac{1}{2} \text { and } 1
\end{equation}`;
// opt C
export const optC13 = String.raw`
\begin{equation}
2 \text { and } 1
\end{equation}`;
// opt D
export const optD13 = String.raw`
\begin{equation}
1 \text { and } 2
\end{equation}`;

// Qtn 14
export const q14 = String.raw`
\begin{equation}
\text { Suppose that } X \text { takes on one of the values 0,1 , and 2 . If for some constant } k \text { , } P(X=i)=k P(X=i-1) \text { for } i=1,2 \text { and } P(X=0)=\frac{1}{7} \text { , then the value of } k \text { is }
\end{equation}`;

// opt A
export const optA14 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt B
export const optB14 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt C
export const optC14 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt D
export const optD14 = String.raw`
\begin{equation}
4
\end{equation}`;

// Qtn 15
export const q15 = String.raw`
\begin{equation}
\text { Which of the following is a discrete random variable? }
\end{equation}
\begin{equation}
\text { I. The number of cars crossing a particular signal in a day. }
\end{equation}
\begin{equation}
\text { II. The number of customers in a queue to buy train tickets at a moment. }
\end{equation}
\begin{equation}
\text { III. The time taken to complete a telephone call. }
\end{equation}`;

// opt A
export const optA15 = String.raw`
\begin{equation}
\text { I and II }
\end{equation}`;
// opt B
export const optB15 = String.raw`
\begin{equation}
\text { II only }
\end{equation}`;
// opt C
export const optC15 = String.raw`
\begin{equation}
\text { III only }
\end{equation}`;	
// opt D
export const optD15 = String.raw`
\begin{equation}
\text { II and III }
\end{equation}`;

// Qtn 16
export const q16 = String.raw`
\begin{equation}
\text { If } f(x)=\left\{\begin{array}{ll}2 x & 0 \leq x \leq a \\ 0 & \text { otherwise }\end{array} \quad\right. \text { is a probability density function of a random variable, then the value of } a \text { is }
\end{equation}`;

// opt A
export const optA16 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt B
export const optB16 = String.raw`
\begin{equation}
2
\end{equation}`;	
// opt C
export const optC16 = String.raw`
\begin{equation}
3
\end{equation}`;	
// opt D
export const optD16 = String.raw`
\begin{equation}
4
\end{equation}`;

// Qtn 17
export const q17 = String.raw`
\begin{equation}
\text { The probability mass function of a random variable is defined as: }
\end{equation}
<table id="tabular">
<tbody>
<tr style="border-top: none !important; border-bottom: none !important;">
<td style="text-align: center; border-left-style: solid !important; border-left-width: 1px !important; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top-style: solid !important; border-top-width: 1px !important; width: auto; vertical-align: middle; "><span class="math-inline "><mathml style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mi>x</mi>
</math></mathml><mathmlword style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mi>x</mi>
</math></mathmlword><asciimath style="display: none;">x</asciimath><mjx-container class="MathJax" jax="SVG"><svg xmlns="http://www.w3.org/2000/svg" width="1.294ex" height="1.025ex" role="img" focusable="false" viewBox="0 -442 572 453" style="vertical-align: -0.025ex;"><g stroke="currentColor" fill="currentColor" stroke-width="0" transform="matrix(1 0 0 -1 0 0)"><g data-mml-node="math"><g data-mml-node="mi"><path data-c="78" d="M52 289Q59 331 106 386T222 442Q257 442 286 424T329 379Q371 442 430 442Q467 442 494 420T522 361Q522 332 508 314T481 292T458 288Q439 288 427 299T415 328Q415 374 465 391Q454 404 425 404Q412 404 406 402Q368 386 350 336Q290 115 290 78Q290 50 306 38T341 26Q378 26 414 59T463 140Q466 150 469 151T485 153H489Q504 153 504 145Q504 144 502 134Q486 77 440 33T333 -11Q263 -11 227 52Q186 -10 133 -10H127Q78 -10 57 16T35 71Q35 103 54 123T99 143Q142 143 142 101Q142 81 130 66T107 46T94 41L91 40Q91 39 97 36T113 29T132 26Q168 26 194 71Q203 87 217 139T245 247T261 313Q266 340 266 352Q266 380 251 392T217 404Q177 404 142 372T93 290Q91 281 88 280T72 278H58Q52 284 52 289Z"></path></g></g></g></svg></mjx-container></span></td>
<td style="text-align: center; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top-style: solid !important; border-top-width: 1px !important; width: auto; vertical-align: middle; "><span class="math-inline "><mathml style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mo>−</mo>
  <mn>2</mn>
</math></mathml><mathmlword style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mo>−</mo>
  <mn>2</mn>
</math></mathmlword><asciimath style="display: none;">-2</asciimath><mjx-container class="MathJax" jax="SVG"><svg xmlns="http://www.w3.org/2000/svg" width="2.891ex" height="1.692ex" role="img" focusable="false" viewBox="0 -666 1278 748" style="vertical-align: -0.186ex;"><g stroke="currentColor" fill="currentColor" stroke-width="0" transform="matrix(1 0 0 -1 0 0)"><g data-mml-node="math"><g data-mml-node="mo"><path data-c="2212" d="M84 237T84 250T98 270H679Q694 262 694 250T679 230H98Q84 237 84 250Z"></path></g><g data-mml-node="mn" transform="translate(778, 0)"><path data-c="32" d="M109 429Q82 429 66 447T50 491Q50 562 103 614T235 666Q326 666 387 610T449 465Q449 422 429 383T381 315T301 241Q265 210 201 149L142 93L218 92Q375 92 385 97Q392 99 409 186V189H449V186Q448 183 436 95T421 3V0H50V19V31Q50 38 56 46T86 81Q115 113 136 137Q145 147 170 174T204 211T233 244T261 278T284 308T305 340T320 369T333 401T340 431T343 464Q343 527 309 573T212 619Q179 619 154 602T119 569T109 550Q109 549 114 549Q132 549 151 535T170 489Q170 464 154 447T109 429Z"></path></g></g></g></svg></mjx-container></span></td>
<td style="text-align: center; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top-style: solid !important; border-top-width: 1px !important; width: auto; vertical-align: middle; "><span class="math-inline "><mathml style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mo>−</mo>
  <mn>1</mn>
</math></mathml><mathmlword style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mo>−</mo>
  <mn>1</mn>
</math></mathmlword><asciimath style="display: none;">-1</asciimath><mjx-container class="MathJax" jax="SVG"><svg xmlns="http://www.w3.org/2000/svg" width="2.891ex" height="1.692ex" role="img" focusable="false" viewBox="0 -666 1278 748" style="vertical-align: -0.186ex;"><g stroke="currentColor" fill="currentColor" stroke-width="0" transform="matrix(1 0 0 -1 0 0)"><g data-mml-node="math"><g data-mml-node="mo"><path data-c="2212" d="M84 237T84 250T98 270H679Q694 262 694 250T679 230H98Q84 237 84 250Z"></path></g><g data-mml-node="mn" transform="translate(778, 0)"><path data-c="31" d="M213 578L200 573Q186 568 160 563T102 556H83V602H102Q149 604 189 617T245 641T273 663Q275 666 285 666Q294 666 302 660V361L303 61Q310 54 315 52T339 48T401 46H427V0H416Q395 3 257 3Q121 3 100 0H88V46H114Q136 46 152 46T177 47T193 50T201 52T207 57T213 61V578Z"></path></g></g></g></svg></mjx-container></span></td>
<td style="text-align: center; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top-style: solid !important; border-top-width: 1px !important; width: auto; vertical-align: middle; ">0</td>
<td style="text-align: center; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top-style: solid !important; border-top-width: 1px !important; width: auto; vertical-align: middle; ">1</td>
<td style="text-align: center; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top-style: solid !important; border-top-width: 1px !important; width: auto; vertical-align: middle; ">2</td>
</tr>
<tr style="border-top: none !important; border-bottom: none !important;">
<td style="text-align: center; border-left-style: solid !important; border-left-width: 1px !important; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top: none !important; width: auto; vertical-align: middle; "><span class="math-inline "><mathml style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mi>f</mi>
  <mo stretchy="false">(</mo>
  <mi>x</mi>
  <mo stretchy="false">)</mo>
</math></mathml><mathmlword style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mi>f</mi>
  <mo stretchy="false">(</mo>
  <mi>x</mi>
  <mo stretchy="false">)</mo>
</math></mathmlword><asciimath style="display: none;">f(x)</asciimath><mjx-container class="MathJax" jax="SVG"><svg xmlns="http://www.w3.org/2000/svg" width="4.299ex" height="2.262ex" role="img" focusable="false" viewBox="0 -750 1900 1000" style="vertical-align: -0.566ex;"><g stroke="currentColor" fill="currentColor" stroke-width="0" transform="matrix(1 0 0 -1 0 0)"><g data-mml-node="math"><g data-mml-node="mi"><path data-c="66" d="M118 -162Q120 -162 124 -164T135 -167T147 -168Q160 -168 171 -155T187 -126Q197 -99 221 27T267 267T289 382V385H242Q195 385 192 387Q188 390 188 397L195 425Q197 430 203 430T250 431Q298 431 298 432Q298 434 307 482T319 540Q356 705 465 705Q502 703 526 683T550 630Q550 594 529 578T487 561Q443 561 443 603Q443 622 454 636T478 657L487 662Q471 668 457 668Q445 668 434 658T419 630Q412 601 403 552T387 469T380 433Q380 431 435 431Q480 431 487 430T498 424Q499 420 496 407T491 391Q489 386 482 386T428 385H372L349 263Q301 15 282 -47Q255 -132 212 -173Q175 -205 139 -205Q107 -205 81 -186T55 -132Q55 -95 76 -78T118 -61Q162 -61 162 -103Q162 -122 151 -136T127 -157L118 -162Z"></path></g><g data-mml-node="mo" transform="translate(550, 0)"><path data-c="28" d="M94 250Q94 319 104 381T127 488T164 576T202 643T244 695T277 729T302 750H315H319Q333 750 333 741Q333 738 316 720T275 667T226 581T184 443T167 250T184 58T225 -81T274 -167T316 -220T333 -241Q333 -250 318 -250H315H302L274 -226Q180 -141 137 -14T94 250Z"></path></g><g data-mml-node="mi" transform="translate(939, 0)"><path data-c="78" d="M52 289Q59 331 106 386T222 442Q257 442 286 424T329 379Q371 442 430 442Q467 442 494 420T522 361Q522 332 508 314T481 292T458 288Q439 288 427 299T415 328Q415 374 465 391Q454 404 425 404Q412 404 406 402Q368 386 350 336Q290 115 290 78Q290 50 306 38T341 26Q378 26 414 59T463 140Q466 150 469 151T485 153H489Q504 153 504 145Q504 144 502 134Q486 77 440 33T333 -11Q263 -11 227 52Q186 -10 133 -10H127Q78 -10 57 16T35 71Q35 103 54 123T99 143Q142 143 142 101Q142 81 130 66T107 46T94 41L91 40Q91 39 97 36T113 29T132 26Q168 26 194 71Q203 87 217 139T245 247T261 313Q266 340 266 352Q266 380 251 392T217 404Q177 404 142 372T93 290Q91 281 88 280T72 278H58Q52 284 52 289Z"></path></g><g data-mml-node="mo" transform="translate(1511, 0)"><path data-c="29" d="M60 749L64 750Q69 750 74 750H86L114 726Q208 641 251 514T294 250Q294 182 284 119T261 12T224 -76T186 -143T145 -194T113 -227T90 -246Q87 -249 86 -250H74Q66 -250 63 -250T58 -247T55 -238Q56 -237 66 -225Q221 -64 221 250T66 725Q56 737 55 738Q55 746 60 749Z"></path></g></g></g></svg></mjx-container></span></td>
<td style="text-align: center; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top: none !important; width: auto; vertical-align: middle; "><span class="math-inline "><mathml style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mi>k</mi>
</math></mathml><mathmlword style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mi>k</mi>
</math></mathmlword><asciimath style="display: none;">k</asciimath><mjx-container class="MathJax" jax="SVG"><svg xmlns="http://www.w3.org/2000/svg" width="1.179ex" height="1.595ex" role="img" focusable="false" viewBox="0 -694 521 705" style="vertical-align: -0.025ex;"><g stroke="currentColor" fill="currentColor" stroke-width="0" transform="matrix(1 0 0 -1 0 0)"><g data-mml-node="math"><g data-mml-node="mi"><path data-c="6B" d="M121 647Q121 657 125 670T137 683Q138 683 209 688T282 694Q294 694 294 686Q294 679 244 477Q194 279 194 272Q213 282 223 291Q247 309 292 354T362 415Q402 442 438 442Q468 442 485 423T503 369Q503 344 496 327T477 302T456 291T438 288Q418 288 406 299T394 328Q394 353 410 369T442 390L458 393Q446 405 434 405H430Q398 402 367 380T294 316T228 255Q230 254 243 252T267 246T293 238T320 224T342 206T359 180T365 147Q365 130 360 106T354 66Q354 26 381 26Q429 26 459 145Q461 153 479 153H483Q499 153 499 144Q499 139 496 130Q455 -11 378 -11Q333 -11 305 15T277 90Q277 108 280 121T283 145Q283 167 269 183T234 206T200 217T182 220H180Q168 178 159 139T145 81T136 44T129 20T122 7T111 -2Q98 -11 83 -11Q66 -11 57 -1T48 16Q48 26 85 176T158 471L195 616Q196 629 188 632T149 637H144Q134 637 131 637T124 640T121 647Z"></path></g></g></g></svg></mjx-container></span></td>
<td style="text-align: center; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top: none !important; width: auto; vertical-align: middle; "><span class="math-inline "><mathml style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mn>2</mn>
  <mi>k</mi>
</math></mathml><mathmlword style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mn>2</mn>
  <mi>k</mi>
</math></mathmlword><asciimath style="display: none;">2k</asciimath><mjx-container class="MathJax" jax="SVG"><svg xmlns="http://www.w3.org/2000/svg" width="2.31ex" height="1.595ex" role="img" focusable="false" viewBox="0 -694 1021 705" style="vertical-align: -0.025ex;"><g stroke="currentColor" fill="currentColor" stroke-width="0" transform="matrix(1 0 0 -1 0 0)"><g data-mml-node="math"><g data-mml-node="mn"><path data-c="32" d="M109 429Q82 429 66 447T50 491Q50 562 103 614T235 666Q326 666 387 610T449 465Q449 422 429 383T381 315T301 241Q265 210 201 149L142 93L218 92Q375 92 385 97Q392 99 409 186V189H449V186Q448 183 436 95T421 3V0H50V19V31Q50 38 56 46T86 81Q115 113 136 137Q145 147 170 174T204 211T233 244T261 278T284 308T305 340T320 369T333 401T340 431T343 464Q343 527 309 573T212 619Q179 619 154 602T119 569T109 550Q109 549 114 549Q132 549 151 535T170 489Q170 464 154 447T109 429Z"></path></g><g data-mml-node="mi" transform="translate(500, 0)"><path data-c="6B" d="M121 647Q121 657 125 670T137 683Q138 683 209 688T282 694Q294 694 294 686Q294 679 244 477Q194 279 194 272Q213 282 223 291Q247 309 292 354T362 415Q402 442 438 442Q468 442 485 423T503 369Q503 344 496 327T477 302T456 291T438 288Q418 288 406 299T394 328Q394 353 410 369T442 390L458 393Q446 405 434 405H430Q398 402 367 380T294 316T228 255Q230 254 243 252T267 246T293 238T320 224T342 206T359 180T365 147Q365 130 360 106T354 66Q354 26 381 26Q429 26 459 145Q461 153 479 153H483Q499 153 499 144Q499 139 496 130Q455 -11 378 -11Q333 -11 305 15T277 90Q277 108 280 121T283 145Q283 167 269 183T234 206T200 217T182 220H180Q168 178 159 139T145 81T136 44T129 20T122 7T111 -2Q98 -11 83 -11Q66 -11 57 -1T48 16Q48 26 85 176T158 471L195 616Q196 629 188 632T149 637H144Q134 637 131 637T124 640T121 647Z"></path></g></g></g></svg></mjx-container></span></td>
<td style="text-align: center; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top: none !important; width: auto; vertical-align: middle; "><span class="math-inline "><mathml style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mn>3</mn>
  <mi>k</mi>
</math></mathml><mathmlword style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mn>3</mn>
  <mi>k</mi>
</math></mathmlword><asciimath style="display: none;">3k</asciimath><mjx-container class="MathJax" jax="SVG"><svg xmlns="http://www.w3.org/2000/svg" width="2.31ex" height="1.62ex" role="img" focusable="false" viewBox="0 -694 1021 716" style="vertical-align: -0.05ex;"><g stroke="currentColor" fill="currentColor" stroke-width="0" transform="matrix(1 0 0 -1 0 0)"><g data-mml-node="math"><g data-mml-node="mn"><path data-c="33" d="M127 463Q100 463 85 480T69 524Q69 579 117 622T233 665Q268 665 277 664Q351 652 390 611T430 522Q430 470 396 421T302 350L299 348Q299 347 308 345T337 336T375 315Q457 262 457 175Q457 96 395 37T238 -22Q158 -22 100 21T42 130Q42 158 60 175T105 193Q133 193 151 175T169 130Q169 119 166 110T159 94T148 82T136 74T126 70T118 67L114 66Q165 21 238 21Q293 21 321 74Q338 107 338 175V195Q338 290 274 322Q259 328 213 329L171 330L168 332Q166 335 166 348Q166 366 174 366Q202 366 232 371Q266 376 294 413T322 525V533Q322 590 287 612Q265 626 240 626Q208 626 181 615T143 592T132 580H135Q138 579 143 578T153 573T165 566T175 555T183 540T186 520Q186 498 172 481T127 463Z"></path></g><g data-mml-node="mi" transform="translate(500, 0)"><path data-c="6B" d="M121 647Q121 657 125 670T137 683Q138 683 209 688T282 694Q294 694 294 686Q294 679 244 477Q194 279 194 272Q213 282 223 291Q247 309 292 354T362 415Q402 442 438 442Q468 442 485 423T503 369Q503 344 496 327T477 302T456 291T438 288Q418 288 406 299T394 328Q394 353 410 369T442 390L458 393Q446 405 434 405H430Q398 402 367 380T294 316T228 255Q230 254 243 252T267 246T293 238T320 224T342 206T359 180T365 147Q365 130 360 106T354 66Q354 26 381 26Q429 26 459 145Q461 153 479 153H483Q499 153 499 144Q499 139 496 130Q455 -11 378 -11Q333 -11 305 15T277 90Q277 108 280 121T283 145Q283 167 269 183T234 206T200 217T182 220H180Q168 178 159 139T145 81T136 44T129 20T122 7T111 -2Q98 -11 83 -11Q66 -11 57 -1T48 16Q48 26 85 176T158 471L195 616Q196 629 188 632T149 637H144Q134 637 131 637T124 640T121 647Z"></path></g></g></g></svg></mjx-container></span></td>
<td style="text-align: center; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top: none !important; width: auto; vertical-align: middle; "><span class="math-inline "><mathml style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mn>4</mn>
  <mi>k</mi>
</math></mathml><mathmlword style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mn>4</mn>
  <mi>k</mi>
</math></mathmlword><asciimath style="display: none;">4k</asciimath><mjx-container class="MathJax" jax="SVG"><svg xmlns="http://www.w3.org/2000/svg" width="2.31ex" height="1.595ex" role="img" focusable="false" viewBox="0 -694 1021 705" style="vertical-align: -0.025ex;"><g stroke="currentColor" fill="currentColor" stroke-width="0" transform="matrix(1 0 0 -1 0 0)"><g data-mml-node="math"><g data-mml-node="mn"><path data-c="34" d="M462 0Q444 3 333 3Q217 3 199 0H190V46H221Q241 46 248 46T265 48T279 53T286 61Q287 63 287 115V165H28V211L179 442Q332 674 334 675Q336 677 355 677H373L379 671V211H471V165H379V114Q379 73 379 66T385 54Q393 47 442 46H471V0H462ZM293 211V545L74 212L183 211H293Z"></path></g><g data-mml-node="mi" transform="translate(500, 0)"><path data-c="6B" d="M121 647Q121 657 125 670T137 683Q138 683 209 688T282 694Q294 694 294 686Q294 679 244 477Q194 279 194 272Q213 282 223 291Q247 309 292 354T362 415Q402 442 438 442Q468 442 485 423T503 369Q503 344 496 327T477 302T456 291T438 288Q418 288 406 299T394 328Q394 353 410 369T442 390L458 393Q446 405 434 405H430Q398 402 367 380T294 316T228 255Q230 254 243 252T267 246T293 238T320 224T342 206T359 180T365 147Q365 130 360 106T354 66Q354 26 381 26Q429 26 459 145Q461 153 479 153H483Q499 153 499 144Q499 139 496 130Q455 -11 378 -11Q333 -11 305 15T277 90Q277 108 280 121T283 145Q283 167 269 183T234 206T200 217T182 220H180Q168 178 159 139T145 81T136 44T129 20T122 7T111 -2Q98 -11 83 -11Q66 -11 57 -1T48 16Q48 26 85 176T158 471L195 616Q196 629 188 632T149 637H144Q134 637 131 637T124 640T121 647Z"></path></g></g></g></svg></mjx-container></span></td>
<td style="text-align: center; border-right-style: solid !important; border-right-width: 1px !important; border-bottom-style: solid !important; border-bottom-width: 1px !important; border-top: none !important; width: auto; vertical-align: middle; "><span class="math-inline "><mathml style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mn>5</mn>
  <mi>k</mi>
</math></mathml><mathmlword style="display: none"><math xmlns="http://www.w3.org/1998/Math/MathML">
  <mn>5</mn>
  <mi>k</mi>
</math></mathmlword><asciimath style="display: none;">5k</asciimath><mjx-container class="MathJax" jax="SVG"><svg xmlns="http://www.w3.org/2000/svg" width="2.31ex" height="1.62ex" role="img" focusable="false" viewBox="0 -694 1021 716" style="vertical-align: -0.05ex;"><g stroke="currentColor" fill="currentColor" stroke-width="0" transform="matrix(1 0 0 -1 0 0)"><g data-mml-node="math"><g data-mml-node="mn"><path data-c="35" d="M164 157Q164 133 148 117T109 101H102Q148 22 224 22Q294 22 326 82Q345 115 345 210Q345 313 318 349Q292 382 260 382H254Q176 382 136 314Q132 307 129 306T114 304Q97 304 95 310Q93 314 93 485V614Q93 664 98 664Q100 666 102 666Q103 666 123 658T178 642T253 634Q324 634 389 662Q397 666 402 666Q410 666 410 648V635Q328 538 205 538Q174 538 149 544L139 546V374Q158 388 169 396T205 412T256 420Q337 420 393 355T449 201Q449 109 385 44T229 -22Q148 -22 99 32T50 154Q50 178 61 192T84 210T107 214Q132 214 148 197T164 157Z"></path></g><g data-mml-node="mi" transform="translate(500, 0)"><path data-c="6B" d="M121 647Q121 657 125 670T137 683Q138 683 209 688T282 694Q294 694 294 686Q294 679 244 477Q194 279 194 272Q213 282 223 291Q247 309 292 354T362 415Q402 442 438 442Q468 442 485 423T503 369Q503 344 496 327T477 302T456 291T438 288Q418 288 406 299T394 328Q394 353 410 369T442 390L458 393Q446 405 434 405H430Q398 402 367 380T294 316T228 255Q230 254 243 252T267 246T293 238T320 224T342 206T359 180T365 147Q365 130 360 106T354 66Q354 26 381 26Q429 26 459 145Q461 153 479 153H483Q499 153 499 144Q499 139 496 130Q455 -11 378 -11Q333 -11 305 15T277 90Q277 108 280 121T283 145Q283 167 269 183T234 206T200 217T182 220H180Q168 178 159 139T145 81T136 44T129 20T122 7T111 -2Q98 -11 83 -11Q66 -11 57 -1T48 16Q48 26 85 176T158 471L195 616Q196 629 188 632T149 637H144Q134 637 131 637T124 640T121 647Z"></path></g></g></g></svg></mjx-container></span></td>
</tr>
</tbody>
</table>
\begin{equation}
\text { Then  } E(X) \text { is equal to: }
\end{equation}`;

// opt A
export const optA17 = String.raw`
\begin{equation}
\frac{1}{15}
\end{equation}`;
// opt B
export const optB17 = String.raw`
\begin{equation}
\frac{1}{10}
\end{equation}`;	
// opt C
export const optC17 = String.raw`
\begin{equation}
\frac{1}{3}
\end{equation}`;	
// opt D
export const optD17 = String.raw`
\begin{equation}
\frac{2}{3}
\end{equation}`;

// Qtn 18
export const q18 = String.raw`
\begin{equation}
\text { Let } X \text { have a Bernoulli distribution with mean } 0.4, \text { then the variance of }(2 X-3) \text { is }
\end{equation}`;

// opt A
export const optA18 = String.raw`
\begin{equation}
0.24
\end{equation}`;
// opt B
export const optB18 = String.raw`
\begin{equation}
0.48
\end{equation}`;	
// opt C
export const optC18 = String.raw`
\begin{equation}
0.6
\end{equation}`;	
// opt D
export const optD18 = String.raw`
\begin{equation}
0.96
\end{equation}`;

// Qtn 19
export const q19 = String.raw`
\begin{equation}
\text { If in 6 trials, } X \text { is a binomial variable which follows the relation } 9 P(X=4)=P(X=2) \text { , then the probability of success is }
\end{equation}`;

// opt A
export const optA19 = String.raw`
\begin{equation}
0.125
\end{equation}`;
// opt B
export const optB19 = String.raw`
\begin{equation}
0.25
\end{equation}`;	
// opt C
export const optC19 = String.raw`
\begin{equation}
0.375
\end{equation}`;	
// opt D
export const optD19 = String.raw`
\begin{equation}
0.75
\end{equation}`;

// Qtn 20
export const q20 = String.raw`
\begin{equation}
\text { A computer salesperson knows from his past experience that he sells computers to one in every twenty customers who enter the showroom. What is the probability that he will sell a computer to exactly two of the next three customers? }
\end{equation}`;

// opt A
export const optA20 = String.raw`
\begin{equation}
\frac{57}{20^{3}}
\end{equation}`;
// opt B
export const optB20 = String.raw`
\begin{equation}
\frac{57}{20^{2}}
\end{equation}`;	
// opt C
export const optC20 = String.raw`
\begin{equation}
\frac{19^{3}}{20^{3}}
\end{equation}`;	
// opt D
export const optD20 = String.raw`
\begin{equation}
\frac{57}{20}
\end{equation}`;

// // Qtn 21
// export const q21 = String.raw`
// `;

// // opt A
// export const optA21 = String.raw`
// `;
// // opt B
// export const optB21 = String.raw`
// `;	
// // opt C
// export const optC21 = String.raw`
// `;	
// // opt D
// export const optD21 = String.raw`
// `;

// // Qtn 22
// export const q22 = String.raw`
// `;

// // opt A
// export const optA22 = String.raw`
// `;
// // opt B
// export const optB22 = String.raw`
// `;	
// // opt C
// export const optC22 = String.raw`
// `;	
// // opt D
// export const optD22 = String.raw`
// `;

// // Qtn 23
// export const q23 = String.raw`
// `;

// // opt A
// export const optA23 = String.raw`
// `;
// // opt B
// export const optB23 = String.raw`
// `;	
// // opt C
// export const optC23 = String.raw`
// `;	
// // opt D
// export const optD23 = String.raw`
// `;

// // Qtn 24
// export const q24 = String.raw`
// `;

// // opt A
// export const optA24 = String.raw`
// `;
// // opt B
// export const optB24 = String.raw`
// `;	
// // opt C
// export const optC24 = String.raw`
// `;	
// // opt D
// export const optD24 = String.raw`
// `;

// // Qtn 25
// export const q25 = String.raw`
// `;

// // opt A
// export const optA25 = String.raw`
// `;
// // opt B
// export const optB25 = String.raw`
// `;	
// // opt C
// export const optC25 = String.raw`
// `;	
// // opt D
// export const optD25 = String.raw`
// `;





