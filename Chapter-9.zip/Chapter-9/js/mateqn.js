// Qtn 1
export const q1 = String.raw`
\begin{equation}
\text { The value of } \int_{0}^{\frac{2}{3}} \frac{d x}{\sqrt{4-9 x^{2}}} \text { is }
\end{equation}` ;

// opt A
export const optA1 = String.raw`
\begin{equation}
\frac{\pi}{6}
\end{equation}`;
// opt B
export const optB1 = String.raw`
\begin{equation}
\frac{\pi}{2}
\end{equation}` ;
// opt C
export const optC1 = String.raw`
\begin{equation}
\frac{\pi}{4}
\end{equation}` ;
// opt D
export const optD1 = String.raw`
\begin{equation}
\pi
\end{equation}` ;

// Qtn 2
export const q2 = String.raw`
\begin{equation}
\text { The value of } \int_{-1}^{2}|x| d x \text { is }
\end{equation}`;
// opt A
export const optA2 = String.raw`
\begin{equation}
\frac{1}{2}
\end{equation}` ;
// opt B
export const optB2 = String.raw`
\begin{equation}
\frac{3}{2}
\end{equation}` ;
// opt C
export const optC2 = String.raw`
\begin{equation}
\frac{5}{2}
\end{equation}` ;
// opt D
export const optD2 = String.raw`
\begin{equation}
\frac{7}{2}
\end{equation}` ;

// Qtn 3
export const q3 = String.raw`
\begin{equation}
\text { For any value of } n \in \mathbb{Z}, \int_{0}^{\pi} e^{\cos ^{2} x} \cos ^{3}[(2 n+1) x] d x \text { is }
\end{equation}`;
// opt A
export const optA3 = String.raw`
\begin{equation}
\frac{\pi}{2}
\end{equation}`;
// opt B
export const optB3 = String.raw`
\begin{equation}
\pi
\end{equation}` ;
// opt C
export const optC3 = String.raw`
\begin{equation}
0
\end{equation}` ;
// opt D
export const optD3 = String.raw`
\begin{equation}
2
\end{equation}` ;

// Qtn 4
export const q4 = String.raw`
\begin{equation}
\text { The value of } \int_{-\frac{\pi}{2}}^{\frac{\pi}{2}} \sin ^{2} x \cos x d x \text { is }
\end{equation}` ;

// opt A
export const optA4 = String.raw`
\begin{equation}
\frac{3}{2}
\end{equation}`;
// opt B
export const optB4 = String.raw`
\begin{equation}
\frac{1}{2}
\end{equation}` ;
// opt C
export const optC4 = String.raw`
\begin{equation}
0
\end{equation}` ;
// opt D
export const optD4 = String.raw`
\begin{equation}
\frac{2}{3}
\end{equation}` ;

// Qtn 5
export const q5 = String.raw`
\begin{equation}
\text { The value of } \int_{-4}^{4}\left[\tan ^{-1}\left(\frac{x^{2}}{x^{4}+1}\right)+\tan ^{-1}\left(\frac{x^{4}+1}{x^{2}}\right)\right] d x \text { is }
\end{equation}` ;

// opt A
export const optA5 = String.raw`
\begin{equation}
\pi
\end{equation}`;
// opt B
export const optB5 = String.raw`
\begin{equation}
2 \pi
\end{equation}` ;
// opt C
export const optC5 = String.raw`
\begin{equation}
3 \pi
\end{equation}` ;
// opt D
export const optD5 = String.raw`
\begin{equation}
4 \pi
\end{equation}` ;

// Qtn 6
export const q6 = String.raw`
\begin{equation}
\text { The value of } \int_{-\frac{\pi}{4}}^{\frac{\pi}{4}}\left(\frac{2 x^{7}-3 x^{5}+7 x^{3}-x+1}{\cos ^{2} x}\right) d x \text { is }
\end{equation}` ;

// opt A
export const optA6 = String.raw`
\begin{equation}
4
\end{equation}`;
// opt B
export const optB6 = String.raw`
\begin{equation}
3
\end{equation}` ;
// opt C
export const optC6 = String.raw`
\begin{equation}
2
\end{equation}` ;
// opt D
export const optD6 = String.raw`
\begin{equation}
0
\end{equation}` ;

// Qtn 7
export const q7 = String.raw`
\begin{equation}
\text { If } f(x)=\int_{0}^{x} t \cos t d t, \text { then } \frac{d f}{d x}=
\end{equation}`;

// opt A
export const optA7 = String.raw`
\begin{equation}
\cos x-x \sin x
\end{equation}`;
// opt B
export const optB7 = String.raw`
\begin{equation}
\sin x+x \cos x
\end{equation}`;
// opt C
export const optC7 = String.raw`
\begin{equation}
x \cos x
\end{equation}`;
// opt D
export const optD7 = String.raw`
\begin{equation}
x \sin x
\end{equation}`;

// Qtn 8
export const q8 = String.raw`
\begin{equation}
\text { The area between } y^{2}=4 x \text { and its latus rectum is }
\end{equation}`;

// opt A
export const optA8 = String.raw`
\begin{equation}
\frac{2}{3}
\end{equation}`;
// opt B
export const optB8 = String.raw`
\begin{equation}
\frac{4}{3}
\end{equation}`;
// opt C
export const optC8 = String.raw`
\begin{equation}
\frac{8}{3}
\end{equation}`;
// opt D
export const optD8 = String.raw`
\begin{equation}
\frac{5}{3}
\end{equation}`;

// Qtn 9
export const q9 = String.raw`
\begin{equation}
\text { The value of } \int_{0}^{1} x(1-x)^{99} d x \text { is }
\end{equation}`;

// opt A
export const optA9 = String.raw`
\begin{equation}
\frac{1}{11000}
\end{equation}`;
// opt B
export const optB9 = String.raw`
\begin{equation}
\frac{1}{10100}
\end{equation}`;
// opt C
export const optC9 = String.raw`
\begin{equation}
\frac{1}{10010}
\end{equation}`;
// opt D
export const optD9 = String.raw`
\begin{equation}
\frac{1}{10001}
\end{equation}`;

// Qtn 10
export const q10 = String.raw`
\begin{equation}
\text { The value of } \int_{0}^{\pi} \frac{d x}{1+5^{\cos x}} \text { is }
\end{equation}`;

// opt A
export const optA10 = String.raw`
\begin{equation}
\frac{\pi}{2}
\end{equation}`;
// opt B
export const optB10 = String.raw`
\begin{equation}
\pi
\end{equation}`;
// opt C
export const optC10 = String.raw`
\begin{equation}
\frac{3 \pi}{2}
\end{equation}`;
// opt D
export const optD10 = String.raw`
\begin{equation}
2 \pi
\end{equation}`;

// Qtn 11
export const q11 = String.raw`
\begin{equation}
\text { If } \frac{\Gamma(n+2)}{\Gamma(n)}=90 \text { then } n \text { is }
\end{equation}`;

// opt A
export const optA11 = String.raw`
\begin{equation}
10
\end{equation}`;
// opt B
export const optB11 = String.raw`
\begin{equation}
5
\end{equation}`;
// opt C
export const optC11 = String.raw`
\begin{equation}
8
\end{equation}`;
// opt D
export const optD11 = String.raw`
\begin{equation}
9
\end{equation}`;

// Qtn 12
export const q12 = String.raw`
\begin{equation}
\text { The value of } \int_{0}^{\frac{\pi}{6}} \cos ^{3} 3 x d x \text { is }
\end{equation}`;

// opt A
export const optA12 = String.raw`
\begin{equation}
\frac{2}{3}
\end{equation}`;
// opt B
export const optB12 = String.raw`
\begin{equation}
\frac{2}{9}
\end{equation}`;
// opt C
export const optC12 = String.raw`
\begin{equation}
\frac{1}{9}
\end{equation}`;
// opt D
export const optD12 = String.raw`
\begin{equation}
\frac{1}{3}
\end{equation}`;

// Qtn 13
export const q13 = String.raw`
\begin{equation}
\text { The value of } \int_{0}^{\pi} \sin ^{4} x d x \text { is }
\end{equation}`;

// opt A
export const optA13 = String.raw`
\begin{equation}
\frac{3 \pi}{10}
\end{equation}`;
// opt B
export const optB13 = String.raw`
\begin{equation}
\frac{3 \pi}{8}
\end{equation}`;
// opt C
export const optC13 = String.raw`
\begin{equation}
\frac{3 \pi}{4}
\end{equation}`;
// opt D
export const optD13 = String.raw`
\begin{equation}
\frac{3 \pi}{2}
\end{equation}`;

// Qtn 14
export const q14 = String.raw`
\begin{equation}
\text { The value of } \int_{0}^{\infty} e^{-3 x} x^{2} d x \text { is }
\end{equation}`;

// opt A
export const optA14 = String.raw`
\begin{equation}
\frac{7}{27}
\end{equation}`;
// opt B
export const optB14 = String.raw`
\begin{equation}
\frac{5}{27}
\end{equation}`;
// opt C
export const optC14 = String.raw`
\begin{equation}
\frac{4}{27}
\end{equation}`;
// opt D
export const optD14 = String.raw`
\begin{equation}
\frac{2}{27}
\end{equation}`;

// Qtn 15
export const q15 = String.raw`
\begin{equation}
\text { If } \int_{0}^{a} \frac{1}{4+x^{2}} d x=\frac{\pi}{8} \text { then } a \text { is }
\end{equation}`;

// opt A
export const optA15 = String.raw`
\begin{equation}
4
\end{equation}`;
// opt B
export const optB15 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt C
export const optC15 = String.raw`
\begin{equation}
3
\end{equation}`;	
// opt D
export const optD15 = String.raw`
\begin{equation}
2
\end{equation}`;

// Qtn 16
export const q16 = String.raw`
\begin{equation}
\text { The volume of solid of revolution of the region bounded by } y^{2}=x(a-x) \text { about } \mathrm{x} \text {-axis is }
\end{equation}`;

// opt A
export const optA16 = String.raw`
\begin{equation}
\pi a^{3}
\end{equation}`;
// opt B
export const optB16 = String.raw`
\begin{equation}
\frac{\pi a^{3}}{4}
\end{equation}`;	
// opt C
export const optC16 = String.raw`
\begin{equation}
\frac{\pi a^{3}}{5}
\end{equation}`;	
// opt D
export const optD16 = String.raw`
\begin{equation}
\frac{\pi a^{3}}{6}
\end{equation}`;

// Qtn 17
export const q17 = String.raw`
\begin{equation}
\text { If } f(x)=\int_{1}^{x} \frac{e^{\sin u}}{u} d u, x>1 \text { and } \int_{1}^{3} \frac{e^{\sin x^{2}}}{x} d x=\frac{1}{2}[f(a)-f(1)] \text {, then one of the possible value of } a \text { is }
\end{equation}`;

// opt A
export const optA17 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt B
export const optB17 = String.raw`
\begin{equation}
6
\end{equation}`;	
// opt C
export const optC17 = String.raw`
\begin{equation}
9
\end{equation}`;	
// opt D
export const optD17 = String.raw`
\begin{equation}
5
\end{equation}`;

// Qtn 18
export const q18 = String.raw`
\begin{equation}
\text { The value of } \int_{0}^{1}\left(\sin ^{-1} x\right)^{2} d x \text { is }
\end{equation}`;

// opt A
export const optA18 = String.raw`
\begin{equation}
\frac{\pi^{2}}{4}-1
\end{equation}`;
// opt B
export const optB18 = String.raw`
\begin{equation}
\frac{\pi^{2}}{4}+2
\end{equation}`;	
// opt C
export const optC18 = String.raw`
\begin{equation}
\frac{\pi^{2}}{4}+1
\end{equation}`;	
// opt D
export const optD18 = String.raw`
\begin{equation}
\frac{\pi^{2}}{4}-2
\end{equation}`;

// Qtn 19
export const q19 = String.raw`
\begin{equation}
\text { The value of } \int_{0}^{a}\left(\sqrt{a^{2}-x^{2}}\right)^{3} d x \text { is }
\end{equation}`;

// opt A
export const optA19 = String.raw`
\begin{equation}
\frac{\pi a^{3}}{16}
\end{equation}`;
// opt B
export const optB19 = String.raw`
\begin{equation}
\frac{3 \pi a^{4}}{16}
\end{equation}`;	
// opt C
export const optC19 = String.raw`
\begin{equation}
\frac{3 \pi a^{2}}{8}
\end{equation}`;	
// opt D
export const optD19 = String.raw`
\begin{equation}
\frac{3 \pi a^{4}}{8}
\end{equation}`;

// Qtn 20
export const q20 = String.raw`
\begin{equation}
\text { If } \int_{0}^{x} f(t) d t=x+\int_{x}^{1} t f(t) d t, \text { then the value of } f(1) \text { is }
\end{equation}`;

// opt A
export const optA20 = String.raw`
\begin{equation}
\frac{1}{2}
\end{equation}`;
// opt B
export const optB20 = String.raw`
\begin{equation}
2
\end{equation}`;	
// opt C
export const optC20 = String.raw`
\begin{equation}
1
\end{equation}`;	
// opt D
export const optD20 = String.raw`
\begin{equation}
\frac{3}{4}
\end{equation}`;

// // Qtn 21
// export const q21 = String.raw`
// `;

// // opt A
// export const optA21 = String.raw`
// `;
// // opt B
// export const optB21 = String.raw`
// `;	
// // opt C
// export const optC21 = String.raw`
// `;	
// // opt D
// export const optD21 = String.raw`
// `;

// // Qtn 22
// export const q22 = String.raw`
// `;

// // opt A
// export const optA22 = String.raw`
// `;
// // opt B
// export const optB22 = String.raw`
// `;	
// // opt C
// export const optC22 = String.raw`
// `;	
// // opt D
// export const optD22 = String.raw`
// `;

// // Qtn 23
// export const q23 = String.raw`
// `;

// // opt A
// export const optA23 = String.raw`
// `;
// // opt B
// export const optB23 = String.raw`
// `;	
// // opt C
// export const optC23 = String.raw`
// `;	
// // opt D
// export const optD23 = String.raw`
// `;

// // Qtn 24
// export const q24 = String.raw`
// `;

// // opt A
// export const optA24 = String.raw`
// `;
// // opt B
// export const optB24 = String.raw`
// `;	
// // opt C
// export const optC24 = String.raw`
// `;	
// // opt D
// export const optD24 = String.raw`
// `;

// // Qtn 25
// export const q25 = String.raw`
// `;

// // opt A
// export const optA25 = String.raw`
// `;
// // opt B
// export const optB25 = String.raw`
// `;	
// // opt C
// export const optC25 = String.raw`
// `;	
// // opt D
// export const optD25 = String.raw`
// `;





