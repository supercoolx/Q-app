// Qtn 1
export const q1 = String.raw`
\begin{equation}
\text { A circular template has a radius of } 10 \mathrm{~cm} \text {. The measurement of radius has an approximate error of } 0.02 \mathrm{~cm} \text { . Then the percentage error in calculating area of this template is }
\end{equation}` ;

// opt A
export const optA1 = String.raw`
\begin{equation}
0.2 \%
\end{equation}`;
// opt B
export const optB1 = String.raw`
\begin{equation}
0.4 \%
\end{equation}` ;
// opt C
export const optC1 = String.raw`
\begin{equation}
0.04 \%
\end{equation}` ;
// opt D
export const optD1 = String.raw`
\begin{equation}
0.08 \%
\end{equation}` ;

// Qtn 2
export const q2 = String.raw`
\begin{equation}
\text { The percentage error of fifth root of 31 is approximately how many times the percentage error in 31? }
\end{equation}`;
// opt A
export const optA2 = String.raw`
\begin{equation}
\frac{1}{31}
\end{equation}` ;
// opt B
export const optB2 = String.raw`
\begin{equation}
\frac{1}{5}
\end{equation}` ;
// opt C
export const optC2 = String.raw`
\begin{equation}
5
\end{equation}` ;
// opt D
export const optD2 = String.raw`
\begin{equation}
31
\end{equation}` ;

// Qtn 3
export const q3 = String.raw`
\begin{equation}
\text { If } u(x, y)=e^{x^{2}+y^{2}}, \text { then } \frac{\partial u}{\partial x} \text { is equal to }
\end{equation}`;
// opt A
export const optA3 = String.raw`
\begin{equation}
e^{x^{2}+y^{2}}
\end{equation}`;
// opt B
export const optB3 = String.raw`
\begin{equation}
2 x u
\end{equation}` ;
// opt C
export const optC3 = String.raw`
\begin{equation}
x^{2} u
\end{equation}` ;
// opt D
export const optD3 = String.raw`
\begin{equation}
y^{2} u
\end{equation}` ;

// Qtn 4
export const q4 = String.raw`
\begin{equation}
\text { If } v(x, y)=\log \left(e^{x}+e^{y}\right), \text { then } \frac{\partial v}{\partial x}+\frac{\partial v}{\partial y} \text { is equal to }
\end{equation}` ;

// opt A
export const optA4 = String.raw`
\begin{equation}
e^{x}+e^{y}
\end{equation}`;
// opt B
export const optB4 = String.raw`
\begin{equation}
\frac{1}{e^{x}+e^{y}}
\end{equation}` ;
// opt C
export const optC4 = String.raw`
\begin{equation}
2
\end{equation}` ;
// opt D
export const optD4 = String.raw`
\begin{equation}
1
\end{equation}` ;

// Qtn 5
export const q5 = String.raw`
\begin{equation}
\text { If } w(x, y)=x^{y}, x>0, \text { then } \frac{\partial w}{\partial x} \text { is equal to }
\end{equation}` ;

// opt A
export const optA5 = String.raw`
\begin{equation}
x^{y} \log x
\end{equation}`;
// opt B
export const optB5 = String.raw`
\begin{equation}
y \log x
\end{equation}` ;
// opt C
export const optC5 = String.raw`
\begin{equation}
y x^{y-1}
\end{equation}` ;
// opt D
export const optD5 = String.raw`
\begin{equation}
x \log y
\end{equation}` ;

// Qtn 6
export const q6 = String.raw`
\begin{equation}
\text { If } f(x, y)=e^{x y}, \text { then } \frac{\partial^{2} f}{\partial x \partial y} \text { is equal to }
\end{equation}` ;

// opt A
export const optA6 = String.raw`
\begin{equation}
x y e^{x y}
\end{equation}`;
// opt B
export const optB6 = String.raw`
\begin{equation}
(1+x y) e^{x y}
\end{equation}` ;
// opt C
export const optC6 = String.raw`
\begin{equation}
(1+y) e^{x y}
\end{equation}` ;
// opt D
export const optD6 = String.raw`
\begin{equation}
(1+x) e^{x y}
\end{equation}` ;

// Qtn 7
export const q7 = String.raw`
\begin{equation}
\text { If we measure the side of a cube to be } 4 \mathrm{~cm} \text { with an error of } 0.1 \mathrm{~cm} \text {, then the error in our calculation of the volume is }
\end{equation}`;

// opt A
export const optA7 = String.raw`
\begin{equation}
0.4 \mathrm{cu.cm}
\end{equation}`;
// opt B
export const optB7 = String.raw`
\begin{equation}
0.45 \mathrm{cu.cm}
\end{equation}`;
// opt C
export const optC7 = String.raw`
\begin{equation}
2 \mathrm{cu.cm}
\end{equation}`;
// opt D
export const optD7 = String.raw`
\begin{equation}
4.8 \mathrm{cu.cm}
\end{equation}`;

// Qtn 8
export const q8 = String.raw`
\begin{equation}
\text { The change in the surface area } S=6 x^{2} \text { of a cube when the edge length varies from } x_{0} \text { to } x_{0}+d x \text { is }
\end{equation}`;

// opt A
export const optA8 = String.raw`
\begin{equation}
12 x_{0}+d x
\end{equation}`;
// opt B
export const optB8 = String.raw`
\begin{equation}
12 x_{0} d x
\end{equation}`;
// opt C
export const optC8 = String.raw`
\begin{equation}
6 x_{0} d x
\end{equation}`;
// opt D
export const optD8 = String.raw`
\begin{equation}
6 x_{0}+d x
\end{equation}`;

// Qtn 9
export const q9 = String.raw`
\begin{equation}
\text { The approximate change in the volume } V \text { of a cube of side } x \text { metres caused by increasing the side by } 1 \% \text { is }
\end{equation}`;

// opt A
export const optA9 = String.raw`
\begin{equation}
0.3 x d x m^{3}
\end{equation}`;
// opt B
export const optB9 = String.raw`
\begin{equation}
0.03 x m^{3}
\end{equation}`;
// opt C
export const optC9 = String.raw`
\begin{equation}
0.03 x^{2} m^{3}
\end{equation}`;
// opt D
export const optD9 = String.raw`
\begin{equation}
0.03 x^{3} m^{3}
\end{equation}`;

// Qtn 10
export const q10 = String.raw`
\begin{equation}
\text { If } g(x, y)=3 x^{2}-5 y+2 y^{2}, x(t)=e^{t} \quad \text { and } y(t)=\cos t, \text { then } \frac{d g}{d t} \text { is equal to }
\end{equation}`;

// opt A
export const optA10 = String.raw`
\begin{equation}
6 e^{2 t}+5 \sin t-4 \cos t \sin t
\end{equation}`;
// opt B
export const optB10 = String.raw`
\begin{equation}
6 e^{2 t}-5 \sin t+4 \cos t \sin t
\end{equation}`;
// opt C
export const optC10 = String.raw`
\begin{equation}
3 e^{2 t}+5 \sin t+4 \cos t \sin t
\end{equation}`;
// opt D
export const optD10 = String.raw`
\begin{equation}
3 e^{2 t}-5 \sin t+4 \cos t \sin t
\end{equation}`;

// Qtn 11
export const q11 = String.raw`
\begin{equation}
\text { If } f(x)=\frac{x}{x+1}, \text { then its differential is given by }
\end{equation}`;

// opt A
export const optA11 = String.raw`
\begin{equation}
\frac{-1}{(x+1)^{2}} d x
\end{equation}`;
// opt B
export const optB11 = String.raw`
\begin{equation}
\frac{1}{(x+1)^{2}} d x
\end{equation}`;
// opt C
export const optC11 = String.raw`
\begin{equation}
\frac{1}{x+1} d x
\end{equation}`;
// opt D
export const optD11 = String.raw`
\begin{equation}
\frac{-1}{x+1} d x
\end{equation}`;

// Qtn 12
export const q12 = String.raw`
\begin{equation}
\text { If } u(x, y)=x^{2}+3 x y+y-2019, \text { then }\left.\frac{\partial u}{\partial x}\right|_{(4,-5)} \text { is equal to }
\end{equation}`;

// opt A
export const optA12 = String.raw`
\begin{equation}
-4
\end{equation}`;
// opt B
export const optB12 = String.raw`
\begin{equation}
-3
\end{equation}`;
// opt C
export const optC12 = String.raw`
\begin{equation}
-7
\end{equation}`;
// opt D
export const optD12 = String.raw`
\begin{equation}
13
\end{equation}`;

// Qtn 13
export const q13 = String.raw`
\begin{equation}
\text { Linear approximation for } g(x)=\cos x \text { at } x=\frac{\pi}{2} \text { is }
\end{equation}`;

// opt A
export const optA13 = String.raw`
\begin{equation}
x+\frac{\pi}{2}
\end{equation}`;
// opt B
export const optB13 = String.raw`
\begin{equation}
-x+\frac{\pi}{2}
\end{equation}`;
// opt C
export const optC13 = String.raw`
\begin{equation}
x-\frac{\pi}{2}
\end{equation}`;
// opt D
export const optD13 = String.raw`
\begin{equation}
-x-\frac{\pi}{2}
\end{equation}`;

// Qtn 14
export const q14 = String.raw`
\begin{equation}
\text { If } w(x, y, z)=x^{2}(y-z)+y^{2}(z-x)+z^{2}(x-y), \text { then } \frac{\partial w}{\partial x}+\frac{\partial w}{\partial y}+\frac{\partial w}{\partial z} \text { is }
\end{equation}`;

// opt A
export const optA14 = String.raw`
\begin{equation}
x y+y z+z x
\end{equation}`;
// opt B
export const optB14 = String.raw`
\begin{equation}
x(y+z)
\end{equation}`;
// opt C
export const optC14 = String.raw`
\begin{equation}
y(z+x)
\end{equation}`;
// opt D
export const optD14 = String.raw`
\begin{equation}
0
\end{equation}`;

// Qtn 15
export const q15 = String.raw`
\begin{equation}
\text { If } f(x, y, z)=x y+y z+z x \text {, then } f_{x}-f_{z} \text { is equal to }
\end{equation}`;

// opt A
export const optA15 = String.raw`
\begin{equation}
z-x
\end{equation}`;
// opt B
export const optB15 = String.raw`
\begin{equation}
y-z
\end{equation}`;
// opt C
export const optC15 = String.raw`
\begin{equation}
x-z
\end{equation}`;	
// opt D
export const optD15 = String.raw`
\begin{equation}
y-x
\end{equation}`;

// // Qtn 16
// export const q16 = String.raw`
// `;

// // opt A
// export const optA16 = String.raw`
// `;
// // opt B
// export const optB16 = String.raw`
// `;	
// // opt C
// export const optC16 = String.raw`
// `;	
// // opt D
// export const optD16 = String.raw`
// `;

// // // Qtn 17
// // export const q17 = String.raw`
// // `;

// // // opt A
// // export const optA17 = String.raw`
// // `;
// // // opt B
// // export const optB17 = String.raw`
// // `;	
// // // opt C
// // export const optC17 = String.raw`
// // `;	
// // // opt D
// // export const optD17 = String.raw`
// // `;

// // // Qtn 18
// // export const q18 = String.raw`
// // `;

// // // opt A
// // export const optA18 = String.raw`
// // `;
// // // opt B
// // export const optB18 = String.raw`
// // `;	
// // // opt C
// // export const optC18 = String.raw`
// // `;	
// // // opt D
// // export const optD18 = String.raw`
// // `;

// // // Qtn 19
// // export const q19 = String.raw`
// // `;

// // // opt A
// // export const optA19 = String.raw`
// // `;
// // // opt B
// // export const optB19 = String.raw`
// // `;	
// // // opt C
// // export const optC19 = String.raw`
// // `;	
// // // opt D
// // export const optD19 = String.raw`
// // `;

// // // Qtn 20
// // export const q20 = String.raw`
// // `;

// // // opt A
// // export const optA20 = String.raw`
// // `;
// // // opt B
// // export const optB20 = String.raw`
// // `;	
// // // opt C
// // export const optC20 = String.raw`
// // `;	
// // // opt D
// // export const optD20 = String.raw`
// // `;

// // // Qtn 21
// // export const q21 = String.raw`
// // `;

// // // opt A
// // export const optA21 = String.raw`
// // `;
// // // opt B
// // export const optB21 = String.raw`
// // `;	
// // // opt C
// // export const optC21 = String.raw`
// // `;	
// // // opt D
// // export const optD21 = String.raw`
// // `;

// // // Qtn 22
// // export const q22 = String.raw`
// // `;

// // // opt A
// // export const optA22 = String.raw`
// // `;
// // // opt B
// // export const optB22 = String.raw`
// // `;	
// // // opt C
// // export const optC22 = String.raw`
// // `;	
// // // opt D
// // export const optD22 = String.raw`
// // `;

// // // Qtn 23
// // export const q23 = String.raw`
// // `;

// // // opt A
// // export const optA23 = String.raw`
// // `;
// // // opt B
// // export const optB23 = String.raw`
// // `;	
// // // opt C
// // export const optC23 = String.raw`
// // `;	
// // // opt D
// // export const optD23 = String.raw`
// // `;

// // // Qtn 24
// // export const q24 = String.raw`
// // `;

// // // opt A
// // export const optA24 = String.raw`
// // `;
// // // opt B
// // export const optB24 = String.raw`
// // `;	
// // // opt C
// // export const optC24 = String.raw`
// // `;	
// // // opt D
// // export const optD24 = String.raw`
// // `;

// // // Qtn 25
// // export const q25 = String.raw`
// // `;

// // // opt A
// // export const optA25 = String.raw`
// // `;
// // // opt B
// // export const optB25 = String.raw`
// // `;	
// // // opt C
// // export const optC25 = String.raw`
// // `;	
// // // opt D
// // export const optD25 = String.raw`
// // `;





