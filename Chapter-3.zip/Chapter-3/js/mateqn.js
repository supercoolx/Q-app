// Qtn 1
export const q1 = String.raw`
\begin{equation}
\text { A zero of } x^{3}+64 \text { is }
\end{equation}` ;

// opt A
export const optA1 = String.raw`
\begin{equation}
0
\end{equation}`;
// opt B
export const optB1 = String.raw`
\begin{equation}
4
\end{equation}` ;
// opt C
export const optC1 = String.raw`
\begin{equation}
4i
\end{equation}` ;
// opt D
export const optD1 = String.raw`
\begin{equation}
-4
\end{equation}` ;

// Qtn 2
export const q2 = String.raw`
\begin{equation}
\text { If  f  and  g  are polynomials of degrees m and n respectively, and if } h(x)=(f \circ g)(x), \text { then the degree of h is }
\end{equation}`;
// opt A
export const optA2 = String.raw`
\begin{equation}
mn
\end{equation}` ;
// opt B
export const optB2 = String.raw`
\begin{equation}
m+n
\end{equation}` ;
// opt C
export const optC2 = String.raw`
\begin{equation}
m^{n}
\end{equation}` ;
// opt D
export const optD2 = String.raw`
\begin{equation}
n^{m}
\end{equation}` ;

// Qtn 3
export const q3 = String.raw`
\begin{equation}
\text { A polynomial equation in } x \text { of degree } n \text { always has }
\end{equation}`;
// opt A
export const optA3 = String.raw`
\begin{equation}
n \text { distinct roots }
\end{equation}`;
// opt B
export const optB3 = String.raw`
\begin{equation}
n \text { real roots }
\end{equation}` ;
// opt C
export const optC3 = String.raw`
\begin{equation}
n \text { complex roots }
\end{equation}` ;
// opt D
export const optD3 = String.raw`
\begin{equation}
\text { at most one root }
\end{equation}` ;

// Qtn 4
export const q4 = String.raw`
\begin{equation}
\text { If } \alpha, \beta, \text { and } \gamma \text { are the zeros of } x^{3}+p x^{2}+q x+r \text {, then } \sum \frac{1}{\alpha} \text { is }
\end{equation}` ;

// opt A
export const optA4 = String.raw`
\begin{equation}
-\frac{q}{r}
\end{equation}`;
// opt B
export const optB4 = String.raw`
\begin{equation}
-\frac{p}{r}
\end{equation}` ;
// opt C
export const optC4 = String.raw`
\begin{equation}
\frac{q}{r}
\end{equation}` ;
// opt D
export const optD4 = String.raw`
\begin{equation}
-\frac{q}{p}
\end{equation}` ;

// Qtn 5
export const q5 = String.raw`
\begin{equation}
\text { The polynomial } x^{3}-k x^{2}+9 x \text { has three real zeros if and only if, } k \text { satisfies }
\end{equation}` ;

// opt A
export const optA5 = String.raw`
\begin{equation}
|k| \leq 6
\end{equation}`;
// opt B
export const optB5 = String.raw`
\begin{equation}
k = 0
\end{equation}` ;
// opt C
export const optC5 = String.raw`
\begin{equation}
|k|>6
\end{equation}` ;
// opt D
export const optD5 = String.raw`
\begin{equation}
|k| \geq 6
\end{equation}` ;

// Qtn 6
export const q6 = String.raw`
\begin{equation}
\text { If } x^{3}+12 x^{2}+10 a x+1999 \text { definitely has a positive zero, if and only if }
\end{equation}` ;

// opt A
export const optA6 = String.raw`
\begin{equation}
a \geq 0
\end{equation}`;
// opt B
export const optB6 = String.raw`
\begin{equation}
a>0
\end{equation}` ;
// opt C
export const optC6 = String.raw`
\begin{equation}
a<0
\end{equation}` ;
// opt D
export const optD6 = String.raw`
\begin{equation}
a \leq 0
\end{equation}` ;

// Qtn 7
export const q7 = String.raw`
\begin{equation}
\text { The polynomial } x^{3}+2 x+3 \text { has }
\end{equation}`;

// opt A
export const optA7 = String.raw`
\begin{equation}
\text { one negative and two imaginary zeros }
\end{equation}`;
// opt B
export const optB7 = String.raw`
\begin{equation}
\text { one positive and two imaginary zeros }
\end{equation}`;
// opt C
export const optC7 = String.raw`
\begin{equation}
\text { three real zeros }
\end{equation}`;
// opt D
export const optD7 = String.raw`
\begin{equation}
\text { no zeros }
\end{equation}`;

// Qtn 8
export const q8 = String.raw`
\begin{equation}
\text { The number of positive zeros of the polynomial } \sum_{j=0}^{n}{ }^{n} C_{r}(-1)^{r} x^{r} \text { is }
\end{equation}`;

// opt A
export const optA8 = String.raw`
\begin{equation}
0
\end{equation}`;
// opt B
export const optB8 = String.raw`
\begin{equation}
n
\end{equation}`;
// opt C
export const optC8 = String.raw`
\begin{equation}
\text < { n}
\end{equation}`;
// opt D
export const optD8 = String.raw`
\begin{equation}
r
\end{equation}`;