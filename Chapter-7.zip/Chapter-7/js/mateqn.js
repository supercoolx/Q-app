// Qtn 1
export const q1 = String.raw`
\begin{equation}
\text { The volume of a sphere is increasing in volume at the rate of } 3 \pi \mathrm{cm}^{3} / \mathrm{sec} \text { . The rate of change of its radius when radius is } \frac{1}{2} \mathrm{~cm}
\end{equation}` ;

// opt A
export const optA1 = String.raw`
\begin{equation}
3 \mathrm{~cm} / \mathrm{s}
\end{equation}`;
// opt B
export const optB1 = String.raw`
\begin{equation}
2 \mathrm{~cm} / \mathrm{s}
\end{equation}` ;
// opt C
export const optC1 = String.raw`
\begin{equation}
1 \mathrm{~cm} / \mathrm{s}
\end{equation}` ;
// opt D
export const optD1 = String.raw`
\begin{equation}
\frac{1}{2} \mathrm{~cm} / \mathrm{s}
\end{equation}` ;

// Qtn 2
export const q2 = String.raw`
\begin{equation}
\text { A balloon rises straight up at } 10 \mathrm{~m} / \mathrm{s} \text { . An observer is } 40 \mathrm{~m} \text { away from the spot where the balloon left the ground. The rate of change of the balloon's angle of elevation in radian per second when the balloon is 30 metres above the ground. }
\end{equation}`;
// opt A
export const optA2 = String.raw`
\begin{equation}
\frac{3}{25} \text { radians/sec }
\end{equation}` ;
// opt B
export const optB2 = String.raw`
\begin{equation}
\frac{4}{25} \text { radians/sec }
\end{equation}` ;
// opt C
export const optC2 = String.raw`
\begin{equation}
\frac{1}{5} \text { radians/sec }
\end{equation}` ;
// opt D
export const optD2 = String.raw`
\begin{equation}
\frac{1}{3} \text { radians/sec }
\end{equation}` ;

// Qtn 3
export const q3 = String.raw`
\begin{equation}
\text { The position of a particle moving along a horizontal line of any time } t \text { is given by } s(t)=3 t^{2}-2 t-8 \text { . The time at which the particle is at rest is }
\end{equation}`;
// opt A
export const optA3 = String.raw`
\begin{equation}
t=0
\end{equation}`;
// opt B
export const optB3 = String.raw`
\begin{equation}
t=\frac{1}{3}
\end{equation}` ;
// opt C
export const optC3 = String.raw`
\begin{equation}
t=1
\end{equation}` ;
// opt D
export const optD3 = String.raw`
\begin{equation}
t=3
\end{equation}` ;

// Qtn 4
export const q4 = String.raw`
\begin{equation}
\text { A stone is thrown up vertically. The height it reaches at time } t \text { seconds is given by } x=80 t-16 t^{2} \text { . The stone reaches the maximum height in time } t \text { seconds is given by }
\end{equation}` ;

// opt A
export const optA4 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt B
export const optB4 = String.raw`
\begin{equation}
2.5
\end{equation}` ;
// opt C
export const optC4 = String.raw`
\begin{equation}
3
\end{equation}` ;
// opt D
export const optD4 = String.raw`
\begin{equation}
3.5
\end{equation}` ;

// Qtn 5
export const q5 = String.raw`
\begin{equation}
\text { The point on the curve } 6 y=x^{3}+2 \text { at which } y \text { -coordinate changes 8 times as fast as } x \text { -coordinate is }
\end{equation}` ;

// opt A
export const optA5 = String.raw`
\begin{equation}
(4,11)
\end{equation}`;
// opt B
export const optB5 = String.raw`
\begin{equation}
(4,-11)
\end{equation}` ;
// opt C
export const optC5 = String.raw`
\begin{equation}
(-4,11)
\end{equation}` ;
// opt D
export const optD5 = String.raw`
\begin{equation}
(-4,-11)
\end{equation}` ;

// Qtn 6
export const q6 = String.raw`
\begin{equation}
\text { The abscissa of the point on the curve } f(x)=\sqrt{8-2 x} \text { at which the slope of the tangent is } -0.25 ?
\end{equation}` ;

// opt A
export const optA6 = String.raw`
\begin{equation}
-8
\end{equation}`;
// opt B
export const optB6 = String.raw`
\begin{equation}
-4
\end{equation}` ;
// opt C
export const optC6 = String.raw`
\begin{equation}
-2
\end{equation}` ;
// opt D
export const optD6 = String.raw`
\begin{equation}
0
\end{equation}` ;

// Qtn 7
export const q7 = String.raw`
\begin{equation}
\text { The slope of the line normal to the curve } f(x)=2 \cos 4 x \text { at } x=\frac{\pi}{12} \text { is }
\end{equation}`;

// opt A
export const optA7 = String.raw`
\begin{equation}
-4 \sqrt{3}
\end{equation}`;
// opt B
export const optB7 = String.raw`
\begin{equation}
-4
\end{equation}`;
// opt C
export const optC7 = String.raw`
\begin{equation}
\frac{\sqrt{3}}{12}
\end{equation}`;
// opt D
export const optD7 = String.raw`
\begin{equation}
4 \sqrt{3}
\end{equation}`;

// Qtn 8
export const q8 = String.raw`
\begin{equation}
\text { The tangent to the curve } y^{2}-x y+9=0 \text { is vertical when }
\end{equation}`;

// opt A
export const optA8 = String.raw`
\begin{equation}
y=0
\end{equation}`;
// opt B
export const optB8 = String.raw`
\begin{equation}
y=\pm \sqrt{3}
\end{equation}`;
// opt C
export const optC8 = String.raw`
\begin{equation}
y=\frac{1}{2}
\end{equation}`;
// opt D
export const optD8 = String.raw`
\begin{equation}
y=\pm 3
\end{equation}`;

// Qtn 9
export const q9 = String.raw`
\begin{equation}
\text { Angle between } y^{2}=x \text { and } x^{2}=y \text { at the origin is }
\end{equation}`;

// opt A
export const optA9 = String.raw`
\begin{equation}
\tan ^{-1} \frac{3}{4}
\end{equation}`;
// opt B
export const optB9 = String.raw`
\begin{equation}
\tan ^{-1}\left(\frac{4}{3}\right)
\end{equation}`;
// opt C
export const optC9 = String.raw`
\begin{equation}
\frac{\pi}{2}
\end{equation}`;
// opt D
export const optD9 = String.raw`
\begin{equation}
\frac{\pi}{4}
\end{equation}`;

// Qtn 10
export const q10 = String.raw`
\begin{equation}
\text { The value of the } \operatorname{limit} \lim _{x \rightarrow 0}\left(\cot x-\frac{1}{x}\right) \text { is }
\end{equation}`;

// opt A
export const optA10 = String.raw`
\begin{equation}
0
\end{equation}`;
// opt B
export const optB10 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt C
export const optC10 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt D
export const optD10 = String.raw`
\begin{equation}
\infty
\end{equation}`;

// Qtn 11
export const q11 = String.raw`
\begin{equation}
\text { The function } \sin ^{4} x+\cos ^{4} x \text { is increasing in the interval }
\end{equation}`;

// opt A
export const optA11 = String.raw`
\begin{equation}
\left[\frac{5 \pi}{8}, \frac{3 \pi}{4}\right]
\end{equation}`;
// opt B
export const optB11 = String.raw`
\begin{equation}
\left[\frac{\pi}{2}, \frac{5 \pi}{8}\right]
\end{equation}`;
// opt C
export const optC11 = String.raw`
\begin{equation}
\left[\frac{\pi}{4}, \frac{\pi}{2}\right]
\end{equation}`;
// opt D
export const optD11 = String.raw`
\begin{equation}
\left[0, \frac{\pi}{4}\right]
\end{equation}`;

// Qtn 12
export const q12 = String.raw`
\begin{equation}
\text { The number given by the Rolle's theorem for the function } x^{3}-3 x^{2}, x \in[0,3] \text { is }
\end{equation}`;

// opt A
export const optA12 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt B
export const optB12 = String.raw`
\begin{equation}
\sqrt{2}
\end{equation}`;
// opt C
export const optC12 = String.raw`
\begin{equation}
\frac{3}{2}
\end{equation}`;
// opt D
export const optD12 = String.raw`
\begin{equation}
2
\end{equation}`;

// Qtn 13
export const q13 = String.raw`
\begin{equation}
\text { The number given by the Mean value theorem for the function } \frac{1}{x}, x \in[1,9] \text { is }
\end{equation}`;

// opt A
export const optA13 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt B
export const optB13 = String.raw`
\begin{equation}
2.5
\end{equation}`;
// opt C
export const optC13 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt D
export const optD13 = String.raw`
\begin{equation}
3.5
\end{equation}`;

// Qtn 14
export const q14 = String.raw`
\begin{equation}
\text { The minimum value of the function }|3-x|+9 \text { is }
\end{equation}`;

// opt A
export const optA14 = String.raw`
\begin{equation}
0
\end{equation}`;
// opt B
export const optB14 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt C
export const optC14 = String.raw`
\begin{equation}
6
\end{equation}`;
// opt D
export const optD14 = String.raw`
\begin{equation}
9
\end{equation}`;

// Qtn 15
export const q15 = String.raw`
\begin{equation}
\text { The maximum slope of the tangent to the curve } y=e^{x} \sin x, x \in[0,2 \pi] \text { is at }
\end{equation}`;

// opt A
export const optA15 = String.raw`
\begin{equation}
x=\frac{\pi}{4}
\end{equation}`;
// opt B
export const optB15 = String.raw`
\begin{equation}
x=\frac{\pi}{2}
\end{equation}`;
// opt C
export const optC15 = String.raw`
\begin{equation}
x=\pi
\end{equation}`;	
// opt D
export const optD15 = String.raw`
\begin{equation}
x=\frac{3 \pi}{2}
\end{equation}`;

// Qtn 16
export const q16 = String.raw`
\begin{equation}
\text { The maximum value of the function } x^{2} e^{-2 x}, x>0 \text { is }
\end{equation}`;

// opt A
export const optA16 = String.raw`
\begin{equation}
\frac{1}{e}
\end{equation}`;
// opt B
export const optB16 = String.raw`
\begin{equation}
\frac{1}{2 e}
\end{equation}`;	
// opt C
export const optC16 = String.raw`
\begin{equation}
\frac{1}{e^{2}}
\end{equation}`;	
// opt D
export const optD16 = String.raw`
\begin{equation}
\frac{4}{e^{4}}
\end{equation}`;

// Qtn 17
export const q17 = String.raw`
\begin{equation}
\text { One of the closest points on the curve } x^{2}-y^{2}=4 \text { to the point }(6,0) \text { is }
\end{equation}`;

// opt A
export const optA17 = String.raw`
\begin{equation}
(2,0)
\end{equation}`;
// opt B
export const optB17 = String.raw`
\begin{equation}
(\sqrt{5}, 1)
\end{equation}`;	
// opt C
export const optC17 = String.raw`
\begin{equation}
(3, \sqrt{5})
\end{equation}`;	
// opt D
export const optD17 = String.raw`
\begin{equation}
(\sqrt{13},-\sqrt{3})
\end{equation}`;

// Qtn 18
export const q18 = String.raw`
\begin{equation}
\text { The maximum value of the product of two positive numbers, when their sum of the squares is 200, is }
\end{equation}`;

// opt A
export const optA18 = String.raw`
\begin{equation}
100
\end{equation}`;
// opt B
export const optB18 = String.raw`
\begin{equation}
25 \sqrt{7}
\end{equation}`;	
// opt C
export const optC18 = String.raw`
\begin{equation}
28
\end{equation}`;	
// opt D
export const optD18 = String.raw`
\begin{equation}
24 \sqrt{14}
\end{equation}`;

// Qtn 19
export const q19 = String.raw`
\begin{equation}
\text { The curve } y=a x^{4}+b x^{2} \text { with } a b>0
\end{equation}`;

// opt A
export const optA19 = String.raw`
\begin{equation}
\text { has no horizontal tangent }
\end{equation}`;
// opt B
export const optB19 = String.raw`
\begin{equation}
\text { is concave up }
\end{equation}`;	
// opt C
export const optC19 = String.raw`
\begin{equation}
\text { is concave down }
\end{equation}`;	
// opt D
export const optD19 = String.raw`
\begin{equation}
\text { has no points of inflection }
\end{equation}`;

// Qtn 20
export const q20 = String.raw`
\begin{equation}
\text { The point of inflection of the curve } y=(x-1)^{3} \text { is }
\end{equation}`;

// opt A
export const optA20 = String.raw`
\begin{equation}
(0,0)
\end{equation}`;
// opt B
export const optB20 = String.raw`
\begin{equation}
(0,1)
\end{equation}`;	
// opt C
export const optC20 = String.raw`
\begin{equation}
(1,0)
\end{equation}`;	
// opt D
export const optD20 = String.raw`
\begin{equation}
(1,1)
\end{equation}`;

// // Qtn 21
// export const q21 = String.raw`
// `;

// // opt A
// export const optA21 = String.raw`
// `;
// // opt B
// export const optB21 = String.raw`
// `;	
// // opt C
// export const optC21 = String.raw`
// `;	
// // opt D
// export const optD21 = String.raw`
// `;

// // Qtn 22
// export const q22 = String.raw`
// `;

// // opt A
// export const optA22 = String.raw`
// `;
// // opt B
// export const optB22 = String.raw`
// `;	
// // opt C
// export const optC22 = String.raw`
// `;	
// // opt D
// export const optD22 = String.raw`
// `;

// // Qtn 23
// export const q23 = String.raw`
// `;

// // opt A
// export const optA23 = String.raw`
// `;
// // opt B
// export const optB23 = String.raw`
// `;	
// // opt C
// export const optC23 = String.raw`
// `;	
// // opt D
// export const optD23 = String.raw`
// `;

// // Qtn 24
// export const q24 = String.raw`
// `;

// // opt A
// export const optA24 = String.raw`
// `;
// // opt B
// export const optB24 = String.raw`
// `;	
// // opt C
// export const optC24 = String.raw`
// `;	
// // opt D
// export const optD24 = String.raw`
// `;

// // Qtn 25
// export const q25 = String.raw`
// `;

// // opt A
// export const optA25 = String.raw`
// `;
// // opt B
// export const optB25 = String.raw`
// `;	
// // opt C
// export const optC25 = String.raw`
// `;	
// // opt D
// export const optD25 = String.raw`
// `;





