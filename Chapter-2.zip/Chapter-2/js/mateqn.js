// Qtn 1
export const q1 = String.raw`
\begin{equation}
i^{n}+i^{n+1}+i^{n+2}+i^{n+3} \text { is }
\end{equation}` ;

// opt A
export const optA1 = String.raw`
\begin{equation}
0
\end{equation}`;
// opt B
export const optB1 = String.raw`
\begin{equation}
1
\end{equation}` ;
// opt C
export const optC1 = String.raw`
\begin{equation}
-1
\end{equation}` ;
// opt D
export const optD1 = String.raw`
\begin{equation}
i
\end{equation}` ;

// Qtn 2
export const q2 = String.raw`
\begin{equation}
\text { The value of } \sum_{n=1}^{13}\left(i^{n}+i^{n-1}\right) \text { is }
\end{equation}`;
// opt A
export const optA2 = String.raw`
\begin{equation}
1+i
\end{equation}` ;
// opt B
export const optB2 = String.raw`
\begin{equation}
i
\end{equation}` ;
// opt C
export const optC2 = String.raw`
\begin{equation}
1
\end{equation}` ;
// opt D
export const optD2 = String.raw`
\begin{equation}
0
\end{equation}` ;

// Qtn 3
export const q3 = String.raw`
\begin{equation}
\text { The area of the triangle formed by the complex numbers z,iz, and z + iz in the Argand’s diagram is }
\end{equation}`;
// opt A
export const optA3 = String.raw`
\begin{equation}
\frac{1}{2}|z|^{2}
\end{equation}`;
// opt B
export const optB3 = String.raw`
\begin{equation}
|z|^{2}
\end{equation}` ;
// opt C
export const optC3 = String.raw`
\begin{equation}
\frac{3}{2}|z|^{2}
\end{equation}` ;
// opt D
export const optD3 = String.raw`
\begin{equation}
2|z|^{2}
\end{equation}` ;

// Qtn 4
export const q4 = String.raw`
\begin{equation}
\text { The conjugate of a complex number is } \frac{1}{i-2} \text {. Then, the complex number is }
\end{equation}` ;

// opt A
export const optA4 = String.raw`
\begin{equation}
\frac{1}{i+2}
\end{equation}`;
// opt B
export const optB4 = String.raw`
\begin{equation}
\frac{-1}{i+2}
\end{equation}` ;
// opt C
export const optC4 = String.raw`
\begin{equation}
\frac{-1}{i-2}
\end{equation}` ;
// opt D
export const optD4 = String.raw`
\begin{equation}
\frac{1}{i-2}
\end{equation}` ;

// Qtn 5
export const q5 = String.raw`
\begin{equation}
\text { If } z=\frac{(\sqrt{3}+i)^{3}(3 i+4)^{2}}{(8+6 i)^{2}} \text {, then }|z| \text { is equal to }
\end{equation}` ;

// opt A
export const optA5 = String.raw`
\begin{equation}
0
\end{equation}`;
// opt B
export const optB5 = String.raw`
\begin{equation}
1
\end{equation}` ;
// opt C
export const optC5 = String.raw`
\begin{equation}
2
\end{equation}` ;
// opt D
export const optD5 = String.raw`
\begin{equation}
3
\end{equation}` ;

// Qtn 6
export const q6 = String.raw`
\begin{equation}
\text { If } z \text { is a non zero complex number, such that } 2 i z^{2}=\bar{z} \text { then }|z| \text { is }
\end{equation}` ;

// opt A
export const optA6 = String.raw`
\begin{equation}
\frac{1}{2}
\end{equation}`;
// opt B
export const optB6 = String.raw`
\begin{equation}
1
\end{equation}` ;
// opt C
export const optC6 = String.raw`
\begin{equation}
2
\end{equation}` ;
// opt D
export const optD6 = String.raw`
\begin{equation}
3
\end{equation}` ;

// Qtn 7
export const q7 = String.raw`
\begin{equation}
\text { If }|z-2+i| \leq 2 \text {, then the greatest value of }|z| \text { is }
\end{equation}`;

// opt A
export const optA7 = String.raw`
\begin{equation}
\sqrt{3}-2
\end{equation}`;
// opt B
export const optB7 = String.raw`
\begin{equation}
\sqrt{3}+2
\end{equation}`;
// opt C
export const optC7 = String.raw`
\begin{equation}
\sqrt{5}-2
\end{equation}`;
// opt D
export const optD7 = String.raw`
\begin{equation}
\sqrt{5}+2
\end{equation}`;

// Qtn 8
export const q8 = String.raw`
\begin{equation}
\text { If }\left|z-\frac{3}{z}\right|=2 \text {, then the least value of }|z| \text { is }
\end{equation}`;

// opt A
export const optA8 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt B
export const optB8 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt C
export const optC8 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt D
export const optD8 = String.raw`
\begin{equation}
5
\end{equation}`;

// Qtn 9
export const q9 = String.raw`
\begin{equation}
\text { If }|z|=1 \text {, then the value of } \frac{1+z}{1+\bar{z}} \text { is }
\end{equation}`;

// opt A
export const optA9 = String.raw`
\begin{equation}
z
\end{equation}`;
// opt B
export const optB9 = String.raw`
\begin{equation}
\bar{Z}
\end{equation}`;
// opt C
export const optC9 = String.raw`
\begin{equation}
\frac{1}{z}
\end{equation}`;
// opt D
export const optD9 = String.raw`
\begin{equation}
1
\end{equation}`;

// Qtn 10
export const q10 = String.raw`
\begin{equation}
\text { The solution of the equation }|z|-z=1+2 i \text { is }
\end{equation}`;

// opt A
export const optA10 = String.raw`
\begin{equation}
\frac{3}{2}-2 i
\end{equation}`;
// opt B
export const optB10 = String.raw`
\begin{equation}
-\frac{3}{2}+2 i
\end{equation}`;
// opt C
export const optC10 = String.raw`
\begin{equation}
2-\frac{3}{2} i
\end{equation}`;
// opt D
export const optD10 = String.raw`
\begin{equation}
2+\frac{3}{2} i
\end{equation}`;

// Qtn 11
export const q11 = String.raw`
\begin{equation}
\text { If }\left|z_{1}\right|=1,\left|z_{2}\right|=2,\left|z_{3}\right|=3 \text { and }\left|9 z_{1} z_{2}+4 z_{1} z_{3}+z_{2} z_{3}\right|=12, \text { then the value of }\left|z_{1}+z_{2}+z_{3}\right| \text { is }
\end{equation}`;

// opt A
export const optA11 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt B
export const optB11 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt C
export const optC11 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt D
export const optD11 = String.raw`
\begin{equation}
4
\end{equation}`;

// Qtn 12
export const q12 = String.raw`
\begin{equation}
\text { If } z \text { is a complex number such that } z \in \mathbb{C} \backslash \mathbb{R} \text { and } z+\frac{1}{z} \in \mathbb{R}, \text { then }|z| \text { is }
\end{equation}`;

// opt A
export const optA12 = String.raw`
\begin{equation}
0
\end{equation}`;
// opt B
export const optB12 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt C
export const optC12 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt D
export const optD12 = String.raw`
\begin{equation}
3
\end{equation}`;

// Qtn 13
export const q13 = String.raw`
\begin{equation}
Z_{1}, Z_{3}, \text { and } Z_{3} \text { are complex numbers such that } Z_{1}+Z_{2}+Z_{3}=0 \text { and } \left|Z_{1}\right|=\left|Z_{2}\right|=\left|Z_{3}\right|=1 \text { then } z_{1}^{2}+z_{2}^{2}+z_{3}^{2} \text { is }
\end{equation}`;

// opt A
export const optA13 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt B
export const optB13 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt C
export const optC13 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt D
export const optD13 = String.raw`
\begin{equation}
0
\end{equation}`;

// Qtn 14
export const q14 = String.raw`
\begin{equation}
\text { If } \frac{z-1}{z+1} \text { is purely imaginary, then }|z| \text { is }
\end{equation}`;

// opt A
export const optA14 = String.raw`
\begin{equation}
\frac{1}{2}
\end{equation}`;
// opt B
export const optB14 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt C
export const optC14 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt D
export const optD14 = String.raw`
\begin{equation}
3
\end{equation}`;

// Qtn 15
export const q15 = String.raw`
\begin{equation}
\text { If } z=x+i y \text { is a complex number such that }|z+2|=|z-2| \text {, then the locus of } z \text { is }
\end{equation}`;

// opt A
export const optA15 = String.raw`
\begin{equation}
\text { real axis }
\end{equation}`;
// opt B
export const optB15 = String.raw`
\begin{equation}
\text { imaginary axis }
\end{equation}`;
// opt C
export const optC15 = String.raw`
\begin{equation}
\text { ellipse }
\end{equation}`;	
// opt D
export const optD15 = String.raw`
\begin{equation}
\text { circle }
\end{equation}`;

// Qtn 16
export const q16 = String.raw`
\begin{equation}
\text { If }(1+i)(1+2 i)(1+3 i) \cdots(1+n i)=x+i y \text {, then } 2 \cdot 5 \cdot 10 \cdots\left(1+n^{2}\right) \text { is }
\end{equation}`;

// opt A
export const optA16 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt B
export const optB16 = String.raw`
\begin{equation}
i
\end{equation}`;	
// opt C
export const optC16 = String.raw`
\begin{equation}
x^{2}+y^{2}
\end{equation}`;	
// opt D
export const optD16 = String.raw`
\begin{equation}
1+n^{2}
\end{equation}`;

// // Qtn 17
// export const q17 = String.raw`
// `;

// // opt A
// export const optA17 = String.raw`
// `;
// // opt B
// export const optB17 = String.raw`
// `;	
// // opt C
// export const optC17 = String.raw`
// `;	
// // opt D
// export const optD17 = String.raw`
// `;

// // Qtn 18
// export const q18 = String.raw`
// `;

// // opt A
// export const optA18 = String.raw`
// `;
// // opt B
// export const optB18 = String.raw`
// `;	
// // opt C
// export const optC18 = String.raw`
// `;	
// // opt D
// export const optD18 = String.raw`
// `;

// // Qtn 19
// export const q19 = String.raw`
// `;

// // opt A
// export const optA19 = String.raw`
// `;
// // opt B
// export const optB19 = String.raw`
// `;	
// // opt C
// export const optC19 = String.raw`
// `;	
// // opt D
// export const optD19 = String.raw`
// `;

// // Qtn 20
// export const q20 = String.raw`
// `;

// // opt A
// export const optA20 = String.raw`
// `;
// // opt B
// export const optB20 = String.raw`
// `;	
// // opt C
// export const optC20 = String.raw`
// `;	
// // opt D
// export const optD20 = String.raw`
// `;

// // Qtn 21
// export const q21 = String.raw`
// `;

// // opt A
// export const optA21 = String.raw`
// `;
// // opt B
// export const optB21 = String.raw`
// `;	
// // opt C
// export const optC21 = String.raw`
// `;	
// // opt D
// export const optD21 = String.raw`
// `;

// // Qtn 22
// export const q22 = String.raw`
// `;

// // opt A
// export const optA22 = String.raw`
// `;
// // opt B
// export const optB22 = String.raw`
// `;	
// // opt C
// export const optC22 = String.raw`
// `;	
// // opt D
// export const optD22 = String.raw`
// `;

// // Qtn 23
// export const q23 = String.raw`
// `;

// // opt A
// export const optA23 = String.raw`
// `;
// // opt B
// export const optB23 = String.raw`
// `;	
// // opt C
// export const optC23 = String.raw`
// `;	
// // opt D
// export const optD23 = String.raw`
// `;

// // Qtn 24
// export const q24 = String.raw`
// `;

// // opt A
// export const optA24 = String.raw`
// `;
// // opt B
// export const optB24 = String.raw`
// `;	
// // opt C
// export const optC24 = String.raw`
// `;	
// // opt D
// export const optD24 = String.raw`
// `;

// // Qtn 25
// export const q25 = String.raw`
// `;

// // opt A
// export const optA25 = String.raw`
// `;
// // opt B
// export const optB25 = String.raw`
// `;	
// // opt C
// export const optC25 = String.raw`
// `;	
// // opt D
// export const optD25 = String.raw`
// `;





