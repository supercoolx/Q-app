// Qtn 1
export const q1 = String.raw`
\begin{equation}
\text { The order and degree of the differential equation } \frac{d^{2} y}{d x^{2}}+\left(\frac{d y}{d x}\right)^{1 / 3}+x^{1 / 4}=0 \text { are respectively }
\end{equation}` ;

// opt A
export const optA1 = String.raw`
\begin{equation}
2,3
\end{equation}`;
// opt B
export const optB1 = String.raw`
\begin{equation}
3,3
\end{equation}` ;
// opt C
export const optC1 = String.raw`
\begin{equation}
2,6
\end{equation}` ;
// opt D
export const optD1 = String.raw`
\begin{equation}
2,4
\end{equation}` ;

// Qtn 2
export const q2 = String.raw`
\begin{equation}
\text { The differential equation representing the family of curves } y=\mathrm{A} \cos (x+B) \text { , where } \mathrm{A} \text { and } \mathrm{B} \text { are parameters, is }
\end{equation}`;
// opt A
export const optA2 = String.raw`
\begin{equation}
\frac{d^{2} y}{d x^{2}}-y=0
\end{equation}` ;
// opt B
export const optB2 = String.raw`
\begin{equation}
\frac{d^{2} y}{d x^{2}}+y=0
\end{equation}` ;
// opt C
export const optC2 = String.raw`
\begin{equation}
\frac{d^{2} y}{d x^{2}}=0
\end{equation}` ;
// opt D
export const optD2 = String.raw`
\begin{equation}
\frac{d^{2} x}{d y^{2}}=0
\end{equation}` ;

// Qtn 3
export const q3 = String.raw`
\begin{equation}
\text { The order and degree of the differential equation } \sqrt{\sin x}(d x+d y)=\sqrt{\cos x}(d x-d y) \text { is }
\end{equation}`;
// opt A
export const optA3 = String.raw`
\begin{equation}
1,2
\end{equation}`;
// opt B
export const optB3 = String.raw`
\begin{equation}
2,2
\end{equation}` ;
// opt C
export const optC3 = String.raw`
\begin{equation}
1,1
\end{equation}` ;
// opt D
export const optD3 = String.raw`
\begin{equation}
2,1
\end{equation}` ;

// Qtn 4
export const q4 = String.raw`
\begin{equation}
\text { The order of the differential equation of all circles with centre at }(h, k) \text { and radius ' } a \text { ' is }
\end{equation}` ;

// opt A
export const optA4 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt B
export const optB4 = String.raw`
\begin{equation}
3
\end{equation}` ;
// opt C
export const optC4 = String.raw`
\begin{equation}
4
\end{equation}` ;
// opt D
export const optD4 = String.raw`
\begin{equation}
1
\end{equation}` ;

// Qtn 5
export const q5 = String.raw`
\begin{equation}
\text { The differential equation of the family of curves } y=\mathrm{A} e^{x}+\mathrm{B} e^{-x} \text {, where } \mathrm{A} \text { and } \mathrm{B} \text { are arbitrary constants is }
\end{equation}` ;

// opt A
export const optA5 = String.raw`
\begin{equation}
\frac{d^{2} y}{d x^{2}}+y=0
\end{equation}`;
// opt B
export const optB5 = String.raw`
\begin{equation}
\frac{d^{2} y}{d x^{2}}-y=0
\end{equation}` ;
// opt C
export const optC5 = String.raw`
\begin{equation}
\frac{d y}{d x}+y=0
\end{equation}` ;
// opt D
export const optD5 = String.raw`
\begin{equation}
\frac{d y}{d x}-y=0
\end{equation}` ;

// Qtn 6
export const q6 = String.raw`
\begin{equation}
\text { The general solution of the differential equation } \frac{d y}{d x}=\frac{y}{x} \text { is }
\end{equation}` ;

// opt A
export const optA6 = String.raw`
\begin{equation}
x y=k
\end{equation}`;
// opt B
export const optB6 = String.raw`
\begin{equation}
y=k \log x
\end{equation}` ;
// opt C
export const optC6 = String.raw`
\begin{equation}
y=k x
\end{equation}` ;
// opt D
export const optD6 = String.raw`
\begin{equation}
\log y=k x
\end{equation}` ;

// Qtn 7
export const q7 = String.raw`
\begin{equation}
\text { The solution of the differential equation } 2 x \frac{d y}{d x}-y=3 \text { represents }
\end{equation}`;

// opt A
export const optA7 = String.raw`
\begin{equation}
\text { straight lines }
\end{equation}`;
// opt B
export const optB7 = String.raw`
\begin{equation}
\text { circles }
\end{equation}`;
// opt C
export const optC7 = String.raw`
\begin{equation}
\text { parabola }
\end{equation}`;
// opt D
export const optD7 = String.raw`
\begin{equation}
\text { ellipse }
\end{equation}`;

// Qtn 8
export const q8 = String.raw`
\begin{equation}
\text { The solution of } \frac{d y}{d x}+p(x) y=0 \text { is }
\end{equation}`;

// opt A
export const optA8 = String.raw`
\begin{equation}
y=c e^{\int p d x}
\end{equation}`;
// opt B
export const optB8 = String.raw`
\begin{equation}
y=c e^{-\int p d x}
\end{equation}`;
// opt C
export const optC8 = String.raw`
\begin{equation}
x=c e^{-\int p d y}
\end{equation}`;
// opt D
export const optD8 = String.raw`
\begin{equation}
x=c e^{\int p d y}
\end{equation}`;

// Qtn 9
export const q9 = String.raw`
\begin{equation}
\text { The integrating factor of the differential equation } \frac{d y}{d x}+y=\frac{1+y}{\lambda} \text { is }
\end{equation}`;

// opt A
export const optA9 = String.raw`
\begin{equation}
\frac{x}{e^{\lambda}}
\end{equation}`;
// opt B
export const optB9 = String.raw`
\begin{equation}
\frac{e^{\lambda}}{x}
\end{equation}`;
// opt C
export const optC9 = String.raw`
\begin{equation}
\lambda e^{x}
\end{equation}`;
// opt D
export const optD9 = String.raw`
\begin{equation}
e^{x}
\end{equation}`;

// Qtn 10
export const q10 = String.raw`
\begin{equation}
\text { The integrating factor of the differential equation } \frac{d y}{d x}+P(x) y=Q(x) \text { is } x, \text { then } P(x)
\end{equation}`;

// opt A
export const optA10 = String.raw`
\begin{equation}
x
\end{equation}`;
// opt B
export const optB10 = String.raw`
\begin{equation}
\frac{x^{2}}{2}
\end{equation}`;
// opt C
export const optC10 = String.raw`
\begin{equation}
\frac{1}{x}
\end{equation}`;
// opt D
export const optD10 = String.raw`
\begin{equation}
\frac{1}{x^{2}}
\end{equation}`;

// Qtn 11
export const q11 = String.raw`
\begin{equation}
\text { The degree of the differential equation } y(x)=1+\frac{d y}{d x}+\frac{1}{1 \cdot 2}\left(\frac{d y}{d x}\right)^{2}+\frac{1}{1 \cdot 2 \cdot 3}\left(\frac{d y}{d x}\right)^{3}+\ldots . \text { is }
\end{equation}`;

// opt A
export const optA11 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt B
export const optB11 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt C
export const optC11 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt D
export const optD11 = String.raw`
\begin{equation}
4
\end{equation}`;

// Qtn 12
export const q12 = String.raw`
\begin{equation}
\text { If } p \text { and } q \text { are the order and degree of the differential equation } y \frac{d y}{d x}+x^{3}\left(\frac{d^{2} y}{d x^{2}}\right)+x y=\cos x \text {, when }
\end{equation}`;

// opt A
export const optA12 = String.raw`
\begin{equation}
p < q
\end{equation}`;
// opt B
export const optB12 = String.raw`
\begin{equation}
p=q
\end{equation}`;
// opt C
export const optC12 = String.raw`
\begin{equation}
p>q
\end{equation}`;
// opt D
export const optD12 = String.raw`
\begin{equation}
p \text { exists and } q \text { does not exist }
\end{equation}`;

// Qtn 13
export const q13 = String.raw`
\begin{equation}
\text { The solution of the differential equation } \frac{d y}{d x}+\frac{1}{\sqrt{1-x^{2}}}=0 \text { is }
\end{equation}`;

// opt A
export const optA13 = String.raw`
\begin{equation}
y+\sin ^{-1} x=c
\end{equation}`;
// opt B
export const optB13 = String.raw`
\begin{equation}
x+\sin ^{-1} y=0
\end{equation}`;
// opt C
export const optC13 = String.raw`
\begin{equation}
y^{2}+2 \sin ^{-1} x=C
\end{equation}`;
// opt D
export const optD13 = String.raw`
\begin{equation}
x^{2}+2 \sin ^{-1} y=0
\end{equation}`;

// Qtn 14
export const q14 = String.raw`
\begin{equation}
\text { The solution of the differential equation } \frac{d y}{d x}=2 x y \text { is }
\end{equation}`;

// opt A
export const optA14 = String.raw`
\begin{equation}
y=C e^{x^{2}}
\end{equation}`;
// opt B
export const optB14 = String.raw`
\begin{equation}
y=2 x^{2}+C
\end{equation}`;
// opt C
export const optC14 = String.raw`
\begin{equation}
y=C e^{-x^{2}}+C
\end{equation}`;
// opt D
export const optD14 = String.raw`
\begin{equation}
y=x^{2}+C
\end{equation}`;

// Qtn 15
export const q15 = String.raw`
\begin{equation}
\text { The general solution of the differential equation } \log \left(\frac{d y}{d x}\right)=x+y \text { is }
\end{equation}`;

// opt A
export const optA15 = String.raw`
\begin{equation}
e^{x}+e^{y}=C
\end{equation}`;
// opt B
export const optB15 = String.raw`
\begin{equation}
e^{x}+e^{-y}=C
\end{equation}`;
// opt C
export const optC15 = String.raw`
\begin{equation}
e^{-x}+e^{y}=C
\end{equation}`;	
// opt D
export const optD15 = String.raw`
\begin{equation}
e^{-x}+e^{-y}=C
\end{equation}`;

// Qtn 16
export const q16 = String.raw`
\begin{equation}
\text { The solution of } \frac{d y}{d x}=2^{y-x} \text { is }
\end{equation}`;

// opt A
export const optA16 = String.raw`
\begin{equation}
2^{x}+2^{y}=C
\end{equation}`;
// opt B
export const optB16 = String.raw`
\begin{equation}
2^{x}-2^{y}=C
\end{equation}`;	
// opt C
export const optC16 = String.raw`
\begin{equation}
\frac{1}{2^{x}}-\frac{1}{2^{y}}=C
\end{equation}`;	
// opt D
export const optD16 = String.raw`
\begin{equation}
x+y=C
\end{equation}`;

// Qtn 17
export const q17 = String.raw`
\begin{equation}
\text { The solution of the differential equation } \frac{d y}{d x}=\frac{y}{x}+\frac{\phi\left(\frac{y}{x}\right)}{\phi^{\prime}\left(\frac{y}{x}\right)} \text { is }
\end{equation}`;

// opt A
export const optA17 = String.raw`
\begin{equation}
x \phi\left(\frac{y}{x}\right)=k
\end{equation}`;
// opt B
export const optB17 = String.raw`
\begin{equation}
\phi\left(\frac{y}{x}\right)=k x
\end{equation}`;	
// opt C
export const optC17 = String.raw`
\begin{equation}
y \phi\left(\frac{y}{x}\right)=k
\end{equation}`;	
// opt D
export const optD17 = String.raw`
\begin{equation}
\phi\left(\frac{y}{x}\right)=k y
\end{equation}`;

// Qtn 18
export const q18 = String.raw`
\begin{equation}
\text { If } \sin x \text { is the integrating factor of the linear differential equation } \frac{d y}{d x}+P y=Q, \text { then } P \text { is }
\end{equation}`;

// opt A
export const optA18 = String.raw`
\begin{equation}
\log \sin x
\end{equation}`;
// opt B
export const optB18 = String.raw`
\begin{equation}
\cos x
\end{equation}`;	
// opt C
export const optC18 = String.raw`
\begin{equation}
\tan x
\end{equation}`;	
// opt D
export const optD18 = String.raw`
\begin{equation}
\cot x
\end{equation}`;

// Qtn 19
export const q19 = String.raw`
\begin{equation}
\text { The number of arbitrary constants in the general solutions of order } n \text { and } n+1 \text { are respectively }
\end{equation}`;

// opt A
export const optA19 = String.raw`
\begin{equation}
n-1, n
\end{equation}`;
// opt B
export const optB19 = String.raw`
\begin{equation}
n, n+1
\end{equation}`;	
// opt C
export const optC19 = String.raw`
\begin{equation}
n+1, n+2
\end{equation}`;	
// opt D
export const optD19 = String.raw`
\begin{equation}
n+1, n
\end{equation}`;

// Qtn 20
export const q20 = String.raw`
\begin{equation}
\text { The number of arbitrary constants in the particular solution of a differential equation of third order is }
\end{equation}`;

// opt A
export const optA20 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt B
export const optB20 = String.raw`
\begin{equation}
2
\end{equation}`;	
// opt C
export const optC20 = String.raw`
\begin{equation}
1
\end{equation}`;	
// opt D
export const optD20 = String.raw`
\begin{equation}
0
\end{equation}`;

// Qtn 21
export const q21 = String.raw`
\begin{equation}
\text { Integrating factor of the differential equation } \frac{d y}{d x}=\frac{x+y+1}{x+1} \text { is }
\end{equation}`;

// opt A
export const optA21 = String.raw`
\begin{equation}
\frac{1}{x+1}
\end{equation}`;
// opt B
export const optB21 = String.raw`
\begin{equation}
x+1
\end{equation}`;	
// opt C
export const optC21 = String.raw`
\begin{equation}
\frac{1}{\sqrt{x+1}}
\end{equation}`;	
// opt D
export const optD21 = String.raw`
\begin{equation}
\sqrt{x+1}
\end{equation}`;

// Qtn 22
export const q22 = String.raw`
\begin{equation}
\text { The population } P \text { in any year } t \text { is such that the rate of increase in the population is proportional to the population. Then }
\end{equation}`;

// opt A
export const optA22 = String.raw`
\begin{equation}
P=C e^{k t}
\end{equation}`;
// opt B
export const optB22 = String.raw`
\begin{equation}
P=C e^{-k t}
\end{equation}`;	
// opt C
export const optC22 = String.raw`
\begin{equation}
P=C k t
\end{equation}`;	
// opt D
export const optD22 = String.raw`
\begin{equation}
P=C
\end{equation}`;

// Qtn 23
export const q23 = String.raw`
\begin{equation}
P \text { is the amount of certain substance left in after time } t \text { . If the rate of evaporation of the substance is proportional to the amount remaining, then }
\end{equation}`;

// opt A
export const optA23 = String.raw`
\begin{equation}
P=C e^{k t}
\end{equation}`;
// opt B
export const optB23 = String.raw`
\begin{equation}
P=C e^{-k t}
\end{equation}`;	
// opt C
export const optC23 = String.raw`
\begin{equation}
P=C k t
\end{equation}`;	
// opt D
export const optD23 = String.raw`
\begin{equation}
P t=C
\end{equation}`;

// Qtn 24
export const q24 = String.raw`
\begin{equation}
\text { If the solution of the differential equation } \frac{d y}{d x}=\frac{a x+3}{2 y+f} \text { represents a circle, then the value of } a \text { is }
\end{equation}`;

// opt A
export const optA24 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt B
export const optB24 = String.raw`
\begin{equation}
-2
\end{equation}`;	
// opt C
export const optC24 = String.raw`
\begin{equation}
1
\end{equation}`;	
// opt D
export const optD24 = String.raw`
\begin{equation}
-1
\end{equation}`;

// Qtn 25
export const q25 = String.raw`
\begin{equation}
\text { The slope at any point of a curve } y=f(x) \text { is given by } \frac{d y}{d x}=3 x^{2} \text { and it passes through } (-1,1) \text { . Then the equation of the curve is }
\end{equation}`;

// opt A
export const optA25 = String.raw`
\begin{equation}
y=x^{3}+2
\end{equation}`;
// opt B
export const optB25 = String.raw`
\begin{equation}
y=3 x^{2}+4
\end{equation}`;	
// opt C
export const optC25 = String.raw`
\begin{equation}
y=3 x^{3}+4
\end{equation}`;	
// opt D
export const optD25 = String.raw`
\begin{equation}
y=x^{3}+5
\end{equation}`;





