// Qtn 1
export const q1 = String.raw`
\begin{equation}
\text { The value of } \sin ^{-1}(\cos x), 0 \leq x \leq \pi \text { is }
\end{equation}` ;

// opt A
export const optA1 = String.raw`
\begin{equation}
\pi-x
\end{equation}`;
// opt B
export const optB1 = String.raw`
\begin{equation}
x-\frac{\pi}{2}
\end{equation}` ;
// opt C
export const optC1 = String.raw`
\begin{equation}
\frac{\pi}{2}-x
\end{equation}` ;
// opt D
export const optD1 = String.raw`
\begin{equation}
x-\pi
\end{equation}` ;

// Qtn 2
export const q2 = String.raw`
\begin{equation}
\text { If } \sin ^{-1} x+\sin ^{-1} y=\frac{2 \pi}{3} ; \text { then } \cos ^{-1} x+\cos ^{-1} y \text { is equal to }
\end{equation}`;
// opt A
export const optA2 = String.raw`
\begin{equation}
\frac{2 \pi}{3}
\end{equation}` ;
// opt B
export const optB2 = String.raw`
\begin{equation}
\frac{\pi}{3}
\end{equation}` ;
// opt C
export const optC2 = String.raw`
\begin{equation}
\frac{\pi}{6}
\end{equation}` ;
// opt D
export const optD2 = String.raw`
\begin{equation}
\pi
\end{equation}` ;

// Qtn 3
export const q3 = String.raw`
\begin{equation}
\sin ^{-1} \frac{3}{5}-\cos ^{-1} \frac{12}{13}+\sec ^{-1} \frac{5}{3}-\operatorname{cosec}^{-1} \frac{13}{12} \text { is equal to }
\end{equation}`;
// opt A
export const optA3 = String.raw`
\begin{equation}
2 \pi
\end{equation}`;
// opt B
export const optB3 = String.raw`
\begin{equation}
\pi
\end{equation}` ;
// opt C
export const optC3 = String.raw`
\begin{equation}
0
\end{equation}` ;
// opt D
export const optD3 = String.raw`
\begin{equation}
\tan ^{-1} \frac{12}{65}
\end{equation}` ;

// Qtn 4
export const q4 = String.raw`
\begin{equation}
\text { If } \sin ^{-1} x=2 \sin ^{-1} \alpha \text { has a solution, then }
\end{equation}` ;

// opt A
export const optA4 = String.raw`
\begin{equation}
|\alpha| \leq \frac{1}{\sqrt{2}}
\end{equation}`;
// opt B
export const optB4 = String.raw`
\begin{equation}
|\alpha| \geq \frac{1}{\sqrt{2}}
\end{equation}` ;
// opt C
export const optC4 = String.raw`
\begin{equation}
|\alpha|<\frac{1}{\sqrt{2}}
\end{equation}` ;
// opt D
export const optD4 = String.raw`
\begin{equation}
|\alpha|>\frac{1}{\sqrt{2}}
\end{equation}` ;

// Qtn 5
export const q5 = String.raw`
\begin{equation}
\sin ^{-1}(\cos x)=\frac{\pi}{2}-x \text { is valid for }
\end{equation}` ;

// opt A
export const optA5 = String.raw`
\begin{equation}
-\pi \leq x \leq 0
\end{equation}`;
// opt B
export const optB5 = String.raw`
\begin{equation}
0 \leq X \leq \pi
\end{equation}` ;
// opt C
export const optC5 = String.raw`
\begin{equation}
-\frac{\pi}{2} \leq X \leq \frac{\pi}{2}
\end{equation}` ;
// opt D
export const optD5 = String.raw`
\begin{equation}
-\frac{\pi}{4} \leq x \leq \frac{3 \pi}{4}
\end{equation}` ;

// Qtn 6
export const q6 = String.raw`
\begin{equation}
\text { If } \sin ^{-1} x+\sin ^{-1} y+\sin ^{-1} z=\frac{3 \pi}{2} \text {, the value of } x^{2017}+y^{2018}+z^{2019}-\frac{9}{x^{101}+y^{101}+z^{101}} \text { is }
\end{equation}` ;

// opt A
export const optA6 = String.raw`
\begin{equation}
0
\end{equation}`;
// opt B
export const optB6 = String.raw`
\begin{equation}
1
\end{equation}` ;
// opt C
export const optC6 = String.raw`
\begin{equation}
2
\end{equation}` ;
// opt D
export const optD6 = String.raw`
\begin{equation}
3
\end{equation}` ;

// Qtn 7
export const q7 = String.raw`
\begin{equation}
\text { If } \cot ^{-1} x=\frac{2 \pi}{5} \text { for some } x \in R \text {, the value of } \tan ^{-1} x \text { is }
\end{equation}`;

// opt A
export const optA7 = String.raw`
\begin{equation}
-\frac{\pi}{10}
\end{equation}`;
// opt B
export const optB7 = String.raw`
\begin{equation}
\frac{\pi}{5}
\end{equation}`;
// opt C
export const optC7 = String.raw`
\begin{equation}
\frac{\pi}{10}
\end{equation}`;
// opt D
export const optD7 = String.raw`
\begin{equation}
-\frac{\pi}{5}
\end{equation}`;

// Qtn 8
export const q8 = String.raw`
\begin{equation}
\text { The domain of the function defined by } f(x)=\sin ^{-1} \sqrt{x-1} \text { is }
\end{equation}`;

// opt A
export const optA8 = String.raw`
\begin{equation}
[1,2]
\end{equation}`;
// opt B
export const optB8 = String.raw`
\begin{equation}
[-1,1]
\end{equation}`;
// opt C
export const optC8 = String.raw`
\begin{equation}
[0,1]
\end{equation}`;
// opt D
export const optD8 = String.raw`
\begin{equation}
[-1,0]
\end{equation}`;

// Qtn 9
export const q9 = String.raw`
\begin{equation}
\text { If } x=\frac{1}{5} \text {, the value of } \cos \left(\cos ^{-1} x+2 \sin ^{-1} x\right) \text { is }
\end{equation}`;

// opt A
export const optA9 = String.raw`
\begin{equation}
-\sqrt{\frac{24}{25}}
\end{equation}`;
// opt B
export const optB9 = String.raw`
\begin{equation}
\sqrt{\frac{24}{25}}
\end{equation}`;
// opt C
export const optC9 = String.raw`
\begin{equation}
\frac{1}{5}
\end{equation}`;
// opt D
export const optD9 = String.raw`
\begin{equation}
-\frac{1}{5}
\end{equation}`;

// Qtn 10
export const q10 = String.raw`
\begin{equation}
\tan ^{-1}\left(\frac{1}{4}\right)+\tan ^{-1}\left(\frac{2}{9}\right) \text { is equal to }
\end{equation}`;

// opt A
export const optA10 = String.raw`
\begin{equation}
\frac{1}{2} \cos ^{-1}\left(\frac{3}{5}\right)
\end{equation}`;
// opt B
export const optB10 = String.raw`
\begin{equation}
\frac{1}{2} \sin ^{-1}\left(\frac{3}{5}\right)
\end{equation}`;
// opt C
export const optC10 = String.raw`
\begin{equation}
\frac{1}{2} \tan ^{-1}\left(\frac{3}{5}\right)
\end{equation}`;
// opt D
export const optD10 = String.raw`
\begin{equation}
\tan ^{-1}\left(\frac{1}{2}\right)
\end{equation}`;

// Qtn 11
export const q11 = String.raw`
\begin{equation}
\text { If the function } f(x)=\sin ^{-1}\left(x^{2}-3\right) \text {, then } x \text { belongs to }
\end{equation}`;

// opt A
export const optA11 = String.raw`
\begin{equation}
[-1,1]
\end{equation}`;
// opt B
export const optB11 = String.raw`
\begin{equation}
[\sqrt{2}, 2]
\end{equation}`;
// opt C
export const optC11 = String.raw`
\begin{equation}
[-2,-\sqrt{2}] \cup[\sqrt{2}, 2]
\end{equation}`;
// opt D
export const optD11 = String.raw`
\begin{equation}
[-2,-\sqrt{2}]
\end{equation}`;

// Qtn 12
export const q12 = String.raw`
\begin{equation}
\text { If } \cot ^{-1} 2 \text { and } \cot ^{-1} 3 \text { are two angles of a triangle, then the third angle is }
\end{equation}`;

// opt A
export const optA12 = String.raw`
\begin{equation}
\frac{\pi}{4}
\end{equation}`;
// opt B
export const optB12 = String.raw`
\begin{equation}
\frac{3 \pi}{4}
\end{equation}`;
// opt C
export const optC12 = String.raw`
\begin{equation}
\frac{\pi}{6}
\end{equation}`;
// opt D
export const optD12 = String.raw`
\begin{equation}
\frac{\pi}{3}
\end{equation}`;

// Qtn 13
export const q13 = String.raw`
\begin{equation}
\sin ^{-1}\left(\tan \frac{\pi}{4}\right)-\sin ^{-1}\left(\sqrt{\frac{3}{x}}\right)=\frac{\pi}{6} \text {. Then } x \text { is a root of the equation }
\end{equation}`;

// opt A
export const optA13 = String.raw`
\begin{equation}
x^{2}-x-6=0
\end{equation}`;
// opt B
export const optB13 = String.raw`
\begin{equation}
x^{2}-x-12=0
\end{equation}`;
// opt C
export const optC13 = String.raw`
\begin{equation}
x^{2}+x-12=0
\end{equation}`;
// opt D
export const optD13 = String.raw`
\begin{equation}
x^{2}+x-6=0
\end{equation}`;

// Qtn 14
export const q14 = String.raw`
\begin{equation}
\sin ^{-1}\left(2 \cos ^{2} x-1\right)+\cos ^{-1}\left(1-2 \sin ^{2} x\right)=
\end{equation}`;

// opt A
export const optA14 = String.raw`
\begin{equation}
\frac{\pi}{2}
\end{equation}`;
// opt B
export const optB14 = String.raw`
\begin{equation}
\frac{\pi}{3}
\end{equation}`;
// opt C
export const optC14 = String.raw`
\begin{equation}
\frac{\pi}{4}
\end{equation}`;
// opt D
export const optD14 = String.raw`
\begin{equation}
\frac{\pi}{6}
\end{equation}`;

// Qtn 15
export const q15 = String.raw`
\begin{equation}
\text { If } \cot ^{-1}(\sqrt{\sin \alpha})+\tan ^{-1}(\sqrt{\sin \alpha})=u \text {, then } \cos 2 u \text { is equal to }
\end{equation}`;

// opt A
export const optA15 = String.raw`
\begin{equation}
\tan ^{2} \alpha
\end{equation}`;
// opt B
export const optB15 = String.raw`
\begin{equation}
0
\end{equation}`;
// opt C
export const optC15 = String.raw`
\begin{equation}
-1
\end{equation}`;	
// opt D
export const optD15 = String.raw`
\begin{equation}
\tan 2 \alpha
\end{equation}`;

// Qtn 16
export const q16 = String.raw`
\begin{equation}
\text { If }|x| \leq 1 \text {, then } 2 \tan ^{-1} x-\sin ^{-1} \frac{2 x}{1+x^{2}} \text { is equal to }
\end{equation}`;

// opt A
export const optA16 = String.raw`
\begin{equation}
\tan ^{-1} x
\end{equation}`;
// opt B
export const optB16 = String.raw`
\begin{equation}
\sin ^{-1} x
\end{equation}`;	
// opt C
export const optC16 = String.raw`
\begin{equation}
0
\end{equation}`;	
// opt D
export const optD16 = String.raw`
\begin{equation}
\pi
\end{equation}`;

// Qtn 17
export const q17 = String.raw`
\begin{equation}
\text { The equation } \tan ^{-1} x-\cot ^{-1} x=\tan ^{-1}\left(\frac{1}{\sqrt{3}}\right) \text { has }
\end{equation}`;

// opt A
export const optA17 = String.raw`
\begin{equation}
\text { no solution }
\end{equation}`;
// opt B
export const optB17 = String.raw`
\begin{equation}
\text { unique solution }
\end{equation}`;	
// opt C
export const optC17 = String.raw`
\begin{equation}
\text { two solutions }
\end{equation}`;	
// opt D
export const optD17 = String.raw`
\begin{equation}
\text { infinite number of solutions }
\end{equation}`;

// Qtn 18
export const q18 = String.raw`
\begin{equation}
\text { If } \sin ^{-1} x+\cot ^{-1}\left(\frac{1}{2}\right)=\frac{\pi}{2} \text {, then } x \text { is equal to }
\end{equation}`;

// opt A
export const optA18 = String.raw`
\begin{equation}
\frac{1}{2}
\end{equation}`;
// opt B
export const optB18 = String.raw`
\begin{equation}
\frac{1}{\sqrt{5}}
\end{equation}`;	
// opt C
export const optC18 = String.raw`
\begin{equation}
\frac{2}{\sqrt{5}}
\end{equation}`;	
// opt D
export const optD18 = String.raw`
\begin{equation}
\frac{\sqrt{3}}{2}
\end{equation}`;

// Qtn 19
export const q19 = String.raw`
\begin{equation}
\text { If } \sin ^{-1} \frac{X}{5}+\operatorname{cosec}^{-1} \frac{5}{4}=\frac{\pi}{2} \text {, then the value of } x \text { is }
\end{equation}`;

// opt A
export const optA19 = String.raw`
\begin{equation}
4
\end{equation}`;
// opt B
export const optB19 = String.raw`
\begin{equation}
5
\end{equation}`;	
// opt C
export const optC19 = String.raw`
\begin{equation}
2
\end{equation}`;	
// opt D
export const optD19 = String.raw`
\begin{equation}
3
\end{equation}`;

// Qtn 20
export const q20 = String.raw`
\begin{equation}
\sin \left(\tan ^{-1} x\right),|x|<1 \text { is equal to }
\end{equation}`;

// opt A
export const optA20 = String.raw`
\begin{equation}
\frac{X}{\sqrt{1-X^{2}}}
\end{equation}`;
// opt B
export const optB20 = String.raw`
\begin{equation}
\frac{1}{\sqrt{1-x^{2}}}
\end{equation}`;	
// opt C
export const optC20 = String.raw`
\begin{equation}
\frac{1}{\sqrt{1+x^{2}}}
\end{equation}`;	
// opt D
export const optD20 = String.raw`
\begin{equation}
\frac{X}{\sqrt{1+X^{2}}}
\end{equation}`;

// // Qtn 21
// export const q21 = String.raw`
// `;

// // opt A
// export const optA21 = String.raw`
// `;
// // opt B
// export const optB21 = String.raw`
// `;	
// // opt C
// export const optC21 = String.raw`
// `;	
// // opt D
// export const optD21 = String.raw`
// `;

// // Qtn 22
// export const q22 = String.raw`
// `;

// // opt A
// export const optA22 = String.raw`
// `;
// // opt B
// export const optB22 = String.raw`
// `;	
// // opt C
// export const optC22 = String.raw`
// `;	
// // opt D
// export const optD22 = String.raw`
// `;

// // Qtn 23
// export const q23 = String.raw`
// `;

// // opt A
// export const optA23 = String.raw`
// `;
// // opt B
// export const optB23 = String.raw`
// `;	
// // opt C
// export const optC23 = String.raw`
// `;	
// // opt D
// export const optD23 = String.raw`
// `;

// // Qtn 24
// export const q24 = String.raw`
// `;

// // opt A
// export const optA24 = String.raw`
// `;
// // opt B
// export const optB24 = String.raw`
// `;	
// // opt C
// export const optC24 = String.raw`
// `;	
// // opt D
// export const optD24 = String.raw`
// `;

// // Qtn 25
// export const q25 = String.raw`
// `;

// // opt A
// export const optA25 = String.raw`
// `;
// // opt B
// export const optB25 = String.raw`
// `;	
// // opt C
// export const optC25 = String.raw`
// `;	
// // opt D
// export const optD25 = String.raw`
// `;





