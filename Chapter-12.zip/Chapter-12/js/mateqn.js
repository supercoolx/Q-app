// Qtn 1
export const q1 = String.raw`
\begin{equation}
\text { A binary operation on a set } S \text { is a function from }
\end{equation}` ;

// opt A
export const optA1 = String.raw`
\begin{equation}
S \rightarrow S
\end{equation}`;
// opt B
export const optB1 = String.raw`
\begin{equation}
(S \times S) \rightarrow S
\end{equation}` ;
// opt C
export const optC1 = String.raw`
\begin{equation}
S \rightarrow(S \times S)
\end{equation}` ;
// opt D
export const optD1 = String.raw`
\begin{equation}
(S \times S) \rightarrow(S \times S)
\end{equation}` ;

// Qtn 2
export const q2 = String.raw`
\begin{equation}
\text { Subtraction is not a binary operation in }
\end{equation}`;
// opt A
export const optA2 = String.raw`
\begin{equation}
\mathbb{R}
\end{equation}` ;
// opt B
export const optB2 = String.raw`
\begin{equation}
\mathbb{Z}
\end{equation}` ;
// opt C
export const optC2 = String.raw`
\begin{equation}
\mathbb{N}
\end{equation}` ;
// opt D
export const optD2 = String.raw`
\begin{equation}
\mathbb{Q}
\end{equation}` ;

// Qtn 3
export const q3 = String.raw`
\begin{equation}
\text { Which one of the following is a binary operation on } \mathbb{N} \text { ? }
\end{equation}`;
// opt A
export const optA3 = String.raw`
\begin{equation}
\text { Subtraction }
\end{equation}`;
// opt B
export const optB3 = String.raw`
\begin{equation}
\text { Multiplication }
\end{equation}` ;
// opt C
export const optC3 = String.raw`
\begin{equation}
\text { Division }
\end{equation}` ;
// opt D
export const optD3 = String.raw`
\begin{equation}
\text { All the above }
\end{equation}` ;

// Qtn 4
export const q4 = String.raw`
\begin{equation}
\text { In the set } \mathbb{R} \text { of real numbers ' } * \text { ' is defined as follows. Which one of the following is not a binary operation on } \mathbb{R} \text { ? }
\end{equation}` ;

// opt A
export const optA4 = String.raw`
\begin{equation}
a * b=\min (a \cdot b)
\end{equation}`;
// opt B
export const optB4 = String.raw`
\begin{equation}
a * b=\max (a, b)
\end{equation}` ;
// opt C
export const optC4 = String.raw`
\begin{equation}
a * b=a
\end{equation}` ;
// opt D
export const optD4 = String.raw`
\begin{equation}
a * b=a^{b}
\end{equation}` ;

// Qtn 5
export const q5 = String.raw`
\begin{equation}
\text { The operation } * \text { defined by } a * b=\frac{a b}{7} \text { is not a binary operation on }
\end{equation}` ;

// opt A
export const optA5 = String.raw`
\begin{equation}
\mathbb{Q}^{+}
\end{equation}`;
// opt B
export const optB5 = String.raw`
\begin{equation}
\mathbb{Z}
\end{equation}` ;
// opt C
export const optC5 = String.raw`
\begin{equation}
\mathbb{R}
\end{equation}` ;
// opt D
export const optD5 = String.raw`
\begin{equation}
\mathbb{C}
\end{equation}` ;

// Qtn 6
export const q6 = String.raw`
\begin{equation}
\text { In the set } \mathbb{Q} \text { define } a \odot b=a+b+a b \text {. For what value of } \mathrm{y}, 3 \odot(y \odot 5)=7 ?
\end{equation}` ;

// opt A
export const optA6 = String.raw`
\begin{equation}
y=\frac{2}{3}
\end{equation}`;
// opt B
export const optB6 = String.raw`
\begin{equation}
y=\frac{-2}{3}
\end{equation}` ;
// opt C
export const optC6 = String.raw`
\begin{equation}
y=\frac{-3}{2}
\end{equation}` ;
// opt D
export const optD6 = String.raw`
\begin{equation}
y=4
\end{equation}` ;

// Qtn 7
export const q7 = String.raw`
\begin{equation}
\text { If } a * b=\sqrt{a^{2}+b^{2}} \text { on the real numbers then } * \text { is }
\end{equation}`;

// opt A
export const optA7 = String.raw`
\begin{equation}
\text { commutative but not associative }
\end{equation}`;
// opt B
export const optB7 = String.raw`
\begin{equation}
\text { associative but not commutative }
\end{equation}`;
// opt C
export const optC7 = String.raw`
\begin{equation}
\text { both commutative and associative }
\end{equation}`;
// opt D
export const optD7 = String.raw`
\begin{equation}
\text { neither commutative nor associative }
\end{equation}`;

// Qtn 8
export const q8 = String.raw`
\begin{equation}
\text { Which one of the following statements has the truth value } T \text { ? }
\end{equation}`;

// opt A
export const optA8 = String.raw`
\begin{equation}
\sin x \text { is an even function. }
\end{equation}`;
// opt B
export const optB8 = String.raw`
\begin{equation}
\text {  Every square matrix is non-singular }
\end{equation}`;
// opt C
export const optC8 = String.raw`
\begin{equation}
\text { The product of complex number and its conjugate is purely imaginary }
\end{equation}`;
// opt D
export const optD8 = String.raw`
\begin{equation}
\sqrt{5} \text { is an irrational number }
\end{equation}`;

// Qtn 9
export const q9 = String.raw`
\begin{equation}
\text { Which one of the following statements has truth value } F \text { ? }
\end{equation}`;

// opt A
export const optA9 = String.raw`
\begin{equation}
\text { Chennai is in India or } \sqrt{2} \text { is an integer }
\end{equation}`;
// opt B
export const optB9 = String.raw`
\begin{equation}
\text { Chennai is in India or } \sqrt{2} \text { is an irrational number }
\end{equation}`;
// opt C
export const optC9 = String.raw`
\begin{equation}
\text { Chennai is in China or } \sqrt{2} \text { is an integer }
\end{equation}`;
// opt D
export const optD9 = String.raw`
\begin{equation}
\text { Chennai is in China or } \sqrt{2} \text { is an irrational number }
\end{equation}`;

// Qtn 10
export const q10 = String.raw`
\begin{equation}
\text { If a compound statement involves 3 simple statements, then the number of rows in the truth table is }
\end{equation}`;

// opt A
export const optA10 = String.raw`
\begin{equation}
9
\end{equation}`;
// opt B
export const optB10 = String.raw`
\begin{equation}
8
\end{equation}`;
// opt C
export const optC10 = String.raw`
\begin{equation}
6
\end{equation}`;
// opt D
export const optD10 = String.raw`
\begin{equation}
3
\end{equation}`;

// Qtn 11
export const q11 = String.raw`
\begin{equation}
\text { Which one is the inverse of the statement }(p \vee q) \rightarrow(p \wedge q) ?
\end{equation}`;

// opt A
export const optA11 = String.raw`
\begin{equation}
(p \wedge q) \rightarrow(p \vee q)
\end{equation}`;
// opt B
export const optB11 = String.raw`
\begin{equation}
\neg(p \vee q) \rightarrow(p \wedge q)
\end{equation}`;
// opt C
export const optC11 = String.raw`
\begin{equation}
(\neg p \vee \neg q) \rightarrow(\neg p \wedge \neg q)
\end{equation}`;
// opt D
export const optD11 = String.raw`
\begin{equation}
(\neg p \wedge \neg q) \rightarrow(\neg p \vee \neg q)
\end{equation}`;

// Qtn 12
export const q12 = String.raw`
\begin{equation}
\text { Which one is the contrapositive of the statement }(p \vee q) \rightarrow r ?
\end{equation}`;

// opt A
export const optA12 = String.raw`
\begin{equation}
\neg r \rightarrow(\neg p \wedge \neg q)
\end{equation}`;
// opt B
export const optB12 = String.raw`
\begin{equation}
\neg r \rightarrow(p \vee q)
\end{equation}`;
// opt C
export const optC12 = String.raw`
\begin{equation}
r \rightarrow(p \wedge q)
\end{equation}`;
// opt D
export const optD12 = String.raw`
\begin{equation}
p \rightarrow(q \vee r)
\end{equation}`;

// Qtn 13
export const q13 = String.raw`
\begin{equation}
\begin{aligned}
&\text { The truth table for }(p \wedge q) \vee \neg q \text { is given below }\\
&\begin{array}{|c|c|c|}
\hline \boldsymbol{p} & \boldsymbol{q} & (\boldsymbol{p} \wedge \boldsymbol{q}) \vee(\neg \boldsymbol{q}) \\
\hline T & T & (a) \\
\hline T & F & (b) \\
\hline F & T & (c) \\
\hline F & F & (d) \\
\hline
\end{array}
\end{aligned}
\end{equation}
\begin{equation}
\text { Which one of the folloing is true ? }
\end{equation}`;

// opt A
export const optA13 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{T} & \mathrm{T} & \mathrm{T} & \mathrm{T} \\
\hline
\end{array}
\end{equation}`;
// opt B
export const optB13 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{T} & \mathrm{F} & \mathrm{T} & \mathrm{T} \\
\hline
\end{array}
\end{equation}`;
// opt C
export const optC13 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{T} & \mathrm{T} & \mathrm{F} & \mathrm{T} \\
\hline
\end{array}
\end{equation}`;
// opt D
export const optD13 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{T} & \mathrm{F} & \mathrm{F} & \mathrm{F} \\
\hline
\end{array}
\end{equation}`;

// Qtn 14
export const q14 = String.raw`
\begin{equation}
\text { In the last column of the truth table for } \neg(p \vee \neg q) \text { the number of final outcomes of the truth value ' } F \text { ' are }
\end{equation}`;

// opt A
export const optA14 = String.raw`
\begin{equation}
1
\end{equation}`;
// opt B
export const optB14 = String.raw`
\begin{equation}
2
\end{equation}`;
// opt C
export const optC14 = String.raw`
\begin{equation}
3
\end{equation}`;
// opt D
export const optD14 = String.raw`
\begin{equation}
4
\end{equation}`;

// Qtn 15
export const q15 = String.raw`
\begin{equation}
\text { Which one of the following is incorrect? For any two propositions } p \text { and } q \text {, we have }
\end{equation}`;

// opt A
export const optA15 = String.raw`
\begin{equation}
\neg(p \vee q) \equiv \neg p \wedge \neg q
\end{equation}`;
// opt B
export const optB15 = String.raw`
\begin{equation}
\neg(p \wedge q) \equiv \neg p \vee \neg q
\end{equation}`;
// opt C
export const optC15 = String.raw`
\begin{equation}
\neg(p \vee q) \equiv \neg p \vee \neg q
\end{equation}`;	
// opt D
export const optD15 = String.raw`
\begin{equation}
\neg(\neg p) \equiv p
\end{equation}`;

// Qtn 16
export const q16 = String.raw`
\begin{equation}
\begin{aligned}
&\begin{array}{|c|c|c|}
\hline \boldsymbol{p} & \boldsymbol{q} & (\boldsymbol{p} \wedge \boldsymbol{q}) \rightarrow \neg \boldsymbol{p} \\
\hline T & T & (a) \\
\hline T & F & (b) \\
\hline F & T & (c) \\
\hline F & F & (d) \\
\hline
\end{array}\\
&\text { Which one of the following is correct for the truth value of }(p \wedge q) \rightarrow \neg p ?
\end{aligned}
\end{equation}`;

// opt A
export const optA16 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{T} & \mathrm{T} & \mathrm{T} & \mathrm{T} \\
\hline
\end{array}
\end{equation}`;
// opt B
export const optB16 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{F} & \mathrm{T} & \mathrm{T} & \mathrm{T} \\
\hline
\end{array}
\end{equation}`;	
// opt C
export const optC16 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{F} & \mathrm{F} & \mathrm{T} & \mathrm{T} \\
\hline
\end{array}
\end{equation}`;	
// opt D
export const optD16 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{T} & \mathrm{T} & \mathrm{T} & \mathrm{F} \\
\hline
\end{array}
\end{equation}`;

// Qtn 17
export const q17 = String.raw`
\begin{equation}
\text { The dual of } \neg(p \vee q) \vee[p \vee(p \wedge \neg r)] \text { is }
\end{equation}`;

// opt A
export const optA17 = String.raw`
\begin{equation}
\neg(p \wedge q) \wedge[p \vee(p \wedge \neg r)]
\end{equation}`;
// opt B
export const optB17 = String.raw`
\begin{equation}
(p \wedge q) \wedge[p \wedge(p \vee \neg r)]
\end{equation}`;	
// opt C
export const optC17 = String.raw`
\begin{equation}
\neg(p \wedge q) \wedge[p \wedge(p \wedge r)]
\end{equation}`;	
// opt D
export const optD17 = String.raw`
\begin{equation}
\neg(p \wedge q) \wedge[p \wedge(p \vee \neg r)]
\end{equation}`;

// Qtn 18
export const q18 = String.raw`
\begin{equation}
\text { The proposition } p \wedge(\neg p \vee q) \text { is }
\end{equation}`;

// opt A
export const optA18 = String.raw`
\begin{equation}
\text { a tautology }
\end{equation}`;
// opt B
export const optB18 = String.raw`
\begin{equation}
\text { a contradiction }
\end{equation}`;	
// opt C
export const optC18 = String.raw`
\begin{equation}
\text { logically equivalent to } p \wedge q
\end{equation}`;	
// opt D
export const optD18 = String.raw`
\begin{equation}
\text { logically equivalent to } p \vee q
\end{equation}`;

// Qtn 19
export const q19 = String.raw`
\begin{equation}
\text { Determine the truth value of each of the following statements: }
\end{equation}
\begin{equation}
\text { (a) } 4+2=5 \text { and } 6+3=9 \text {ㅤㅤ} \text { (b) } 3+2=5 \text { and } 6+1=7
\end{equation}
\begin{equation}
\text { (c) } 4+5=9 \text { and } 1+2=4 \text {ㅤㅤ} \text { (d) } 3+2=5 \text {and } 4+7=11
\end{equation}`;

// opt A
export const optA19 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{F} & \mathrm{T} & \mathrm{F} & \mathrm{T} \\
\hline
\end{array}
\end{equation}`;
// opt B
export const optB19 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{T} & \mathrm{F} & \mathrm{T} & \mathrm{F} \\
\hline
\end{array}
\end{equation}`;	
// opt C
export const optC19 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{T} & \mathrm{T} & \mathrm{F} & \mathrm{F} \\
\hline
\end{array}
\end{equation}`;	
// opt D
export const optD19 = String.raw`
\begin{equation}
\begin{array}{|c|c|c|c|}
\hline \text { (a) } & \text { (b) } & \text { (c) } & \text { (d) } \\
\hline \mathrm{F} & \mathrm{F} & \mathrm{T} & \mathrm{T} \\
\hline
\end{array}
\end{equation}`;

// Qtn 20
export const q20 = String.raw`
\begin{equation}
\text { Which one of the following is not true? }
\end{equation}`;

// opt A
export const optA20 = String.raw`
\begin{equation}
\text {  Negation of a negation of a statement is the statement itself. }
\end{equation}`;
// opt B
export const optB20 = String.raw`
\begin{equation}
\text { If the last column of the truth table contains only } T \text { then it is a tautology. }
\end{equation}`;	
// opt C
export const optC20 = String.raw`
\begin{equation}
\text { If the last column of its truth table contains only } F \text { then it is a contradiction. }
\end{equation}`;	
// opt D
export const optD20 = String.raw`
\begin{equation}
\text { If } p \text { and } q \text { are any two statements then } p \leftrightarrow q \text { is a tautology. }
\end{equation}`;

// // Qtn 21
// export const q21 = String.raw`
// `;

// // opt A
// export const optA21 = String.raw`
// `;
// // opt B
// export const optB21 = String.raw`
// `;	
// // opt C
// export const optC21 = String.raw`
// `;	
// // opt D
// export const optD21 = String.raw`
// `;

// // Qtn 22
// export const q22 = String.raw`
// `;

// // opt A
// export const optA22 = String.raw`
// `;
// // opt B
// export const optB22 = String.raw`
// `;	
// // opt C
// export const optC22 = String.raw`
// `;	
// // opt D
// export const optD22 = String.raw`
// `;

// // Qtn 23
// export const q23 = String.raw`
// `;

// // opt A
// export const optA23 = String.raw`
// `;
// // opt B
// export const optB23 = String.raw`
// `;	
// // opt C
// export const optC23 = String.raw`
// `;	
// // opt D
// export const optD23 = String.raw`
// `;

// // Qtn 24
// export const q24 = String.raw`
// `;

// // opt A
// export const optA24 = String.raw`
// `;
// // opt B
// export const optB24 = String.raw`
// `;	
// // opt C
// export const optC24 = String.raw`
// `;	
// // opt D
// export const optD24 = String.raw`
// `;

// // Qtn 25
// export const q25 = String.raw`
// `;

// // opt A
// export const optA25 = String.raw`
// `;
// // opt B
// export const optB25 = String.raw`
// `;	
// // opt C
// export const optC25 = String.raw`
// `;	
// // opt D
// export const optD25 = String.raw`
// `;





